import type { Metadata } from "next";
import { Chakra_Petch, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const chakraPetch = Chakra_Petch({
  variable: "--font-head",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

const ibmPlexMono = IBM_Plex_Mono({
  variable: "--font",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  title: "MOTHERLODE — Mineral Survey Console",
  description:
    "A mineral reconnaissance satellite in your browser. The deposits are real, the data is public. Keyless, local, and built with React + Next.js.",
  keywords: [
    "mining", "minerals", "geology", "copper", "lithium", "gold",
    "Next.js", "React", "TypeScript", "visualization",
  ],
  authors: [{ name: "MOTHERLODE" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "MOTHERLODE — Mineral Survey Console",
    description: "A mineral reconnaissance satellite in your browser.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning data-style="normal">
      <body
        className={`${chakraPetch.variable} ${ibmPlexMono.variable} antialiased`}
        style={{
          background: '#030608',
          color: '#cfe0d6',
          fontFamily: 'var(--font), "IBM Plex Mono", monospace',
          overflow: 'hidden',
          userSelect: 'none',
        }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

import MotherlodeApp from '@/components/motherlode/MotherlodeApp';

export default function Home() {
  return <MotherlodeApp />;
}

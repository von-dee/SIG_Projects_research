'use client';

import { useEffect, useRef, useState } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { runCommand } from '@/lib/motherlode/commands';

export default function Console() {
  const consoleLines = useStore((s) => s.consoleLines);
  const pushConsole = useStore((s) => s.pushConsole);
  const clearConsole = useStore((s) => s.clearConsole);
  const [history, setHistory] = useState<string[]>([]);
  const [hIdx, setHIdx] = useState(-1);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const clogRef = useRef<HTMLDivElement | null>(null);

  // Scroll to bottom on new lines
  useEffect(() => {
    if (clogRef.current) clogRef.current.scrollTop = clogRef.current.scrollHeight;
  }, [consoleLines]);

  // Welcome
  useEffect(() => {
    if (consoleLines.length === 0) {
      pushConsole('MOTHERLODE online. Keyless boot — 91 mines, 11 tailings records, 7 plants. Try "help", or just click a contact.', 'c-ok');
      pushConsole('Console: "track grasberg", "show lithium", "nvg", "tour copper", "pit", "fly to chile". Keyboard: 1-7 sensors · D detection · P pit · T next contact · / console.', 'c-dim');
    }
  }, []);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = inputRef.current?.value.trim();
    if (!raw) return;
    setHistory((h) => [raw, ...h].slice(0, 100));
    setHIdx(-1);
    if (inputRef.current) inputRef.current.value = '';
    pushConsole('<span class="c-warn">ML▸</span> ' + raw, 'c-dim');
    runCommand(raw);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      const ni = Math.min(hIdx + 1, history.length - 1);
      setHIdx(ni);
      if (inputRef.current && history[ni] !== undefined) inputRef.current.value = history[ni];
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const ni = Math.max(hIdx - 1, -1);
      setHIdx(ni);
      if (inputRef.current) inputRef.current.value = ni < 0 ? '' : history[ni];
    } else if (e.key === 'l' && e.ctrlKey) {
      e.preventDefault();
      clearConsole();
    }
  };

  return (
    <div
      id="console"
      className="fixed left-3 bottom-[46px] w-[492px] z-[46] bg-[var(--panel)] border border-[var(--brd)] backdrop-blur-[5px] max-w-[calc(100vw-24px)]"
    >
      <div className="flex items-center gap-2 px-2.5 py-1 border-b border-[var(--brd)] text-[9px] tracking-[0.2em] text-[var(--dim)]">
        <b className="text-[var(--acc)] font-semibold tracking-[0.24em]">ML CONSOLE</b>
        <span>LOCAL PARSER · NO KEY REQUIRED · TRY "HELP"</span>
      </div>
      <div
        ref={clogRef}
        className="max-h-[118px] overflow-y-auto px-2.5 py-1.5 text-[10.5px] leading-[1.5]"
      >
        {consoleLines.map((line) => (
          <div
            key={line.id}
            className={line.cls}
            dangerouslySetInnerHTML={{ __html: line.html }}
          />
        ))}
      </div>
      <form
        onSubmit={onSubmit}
        className="flex items-center gap-2 px-2.5 py-1 border-t border-[var(--brd)]"
      >
        <span className="pfx text-[var(--acc)] text-[11px]">ML▸</span>
        <input
          id="cin"
          ref={inputRef}
          onKeyDown={onKey}
          autoComplete="off"
          spellCheck={false}
          className="flex-1 bg-transparent border-none px-0 outline-none text-[12px] text-[var(--txt)]"
          style={{ fontFamily: 'var(--font)' }}
          placeholder="type a command — try: track grasberg · nvg · tour copper · pit"
        />
      </form>
    </div>
  );
}

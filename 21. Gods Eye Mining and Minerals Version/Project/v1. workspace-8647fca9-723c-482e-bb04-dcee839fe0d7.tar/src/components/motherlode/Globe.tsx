'use client';

import { useEffect, useRef } from 'react';
import { useStore, siteOn, markerColor } from '@/lib/motherlode/store';
import { SITES } from '@/lib/motherlode/sites';
import { COMMS } from '@/lib/motherlode/data';
import { STYLES } from '@/lib/motherlode/styles';
import { LAND, SEAS, LCOL } from '@/lib/motherlode/land';
import {
  TAU, hexA, hash, kindOf, GLY, HAZCOL, haversine, clamp, fmtN,
} from '@/lib/motherlode/constants';
import { project, rawDir, globeR, stepCam, centerLatLon, flyTo } from '@/lib/motherlode/geometry';
import { runCommand, endTour, nextTourStep } from '@/lib/motherlode/commands';
import { STARS as _STARS } from './stars';

export default function Globe() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number>(0);
  const lastTRef = useRef<number>(0);
  const fpsRef = useRef<{ last: number; frames: number; lastFpsT: number; fps: number }>({
    last: 0,
    frames: 0,
    lastFpsT: 0,
    fps: 60,
  });
  const draggingRef = useRef(false);
  const dragMovedRef = useRef(false);
  const pointersRef = useRef<Map<number, [number, number]>>(new Map());
  const pinchDRef = useRef(0);

  // Pointer handlers (attached imperatively for performance)
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;

    const onDown = (e: PointerEvent) => {
      pointersRef.current.set(e.pointerId, [e.clientX, e.clientY]);
      useStore.getState().setLastPointer(performance.now());
      if (pointersRef.current.size === 2) {
        const a = [...pointersRef.current.values()];
        pinchDRef.current = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]);
      }
      draggingRef.current = true;
      dragMovedRef.current = false;
      const cam = useStore.getState().cam;
      cam.anim = null;
      cam.vyaw = 0;
      cam.vtilt = 0;
      c.classList.add('grab');
      try { c.setPointerCapture(e.pointerId); } catch {}
    };

    const onMove = (e: PointerEvent) => {
      useStore.getState().setLastPointer(performance.now());
      if (pointersRef.current.has(e.pointerId)) {
        pointersRef.current.set(e.pointerId, [e.clientX, e.clientY]);
      }
      if (pointersRef.current.size === 2) {
        const a = [...pointersRef.current.values()];
        const d = Math.hypot(a[0][0] - a[1][0], a[0][1] - a[1][1]);
        const cam = useStore.getState().cam;
        if (pinchDRef.current > 0)
          cam.zoomT = clamp((cam.zoomT * d) / pinchDRef.current, 0.9, 12);
        pinchDRef.current = d;
        dragMovedRef.current = true;
        return;
      }
      if (!draggingRef.current) return;
      const mx = e.movementX || 0;
      const my = e.movementY || 0;
      if (Math.abs(mx) + Math.abs(my) > 0) {
        if (Math.abs(mx) + Math.abs(my) > 3) dragMovedRef.current = true;
        const cam = useStore.getState().cam;
        const k = 0.16 / Math.max(1, cam.zoom);
        cam.yaw += mx * k;
        cam.tilt = clamp(cam.tilt - my * k, -1.25, 1.25);
        cam.vyaw = mx * k * 0.4;
        cam.vtilt = -my * k * 0.4;
        const st = useStore.getState();
        if (st.tour && Math.abs(mx * k) + Math.abs(my * k) > 0.01) endTour(st);
      }
    };

    const endPointer = (e: PointerEvent) => {
      pointersRef.current.delete(e.pointerId);
      if (pointersRef.current.size < 2) pinchDRef.current = 0;
      if (!draggingRef.current) return;
      draggingRef.current = false;
      c.classList.remove('grab');
      if (dragMovedRef.current) return;
      const st = useStore.getState();
      const W = st.W, H = st.H;
      let best: (typeof SITES)[number] | null = null;
      let bd = 18;
      for (const s of SITES) {
        if (!s.vis || !siteOn(s, st)) continue;
        const d = Math.hypot((s.sx ?? 0) - e.clientX, (s.sy ?? 0) - e.clientY);
        if (d < bd) { bd = d; best = s; }
      }
      if (best) {
        st.trackSite(best);
        st.pushConsole('TRACKING ▸ ' + best.name.toUpperCase() + ' [' + best.code + '] — ' + best.note, 'c-ok');
      } else if (st.track) {
        st.trackSite(null);
      }
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      useStore.getState().setLastPointer(performance.now());
      const cam = useStore.getState().cam;
      cam.zoomT = clamp(cam.zoomT * Math.exp(-e.deltaY * 0.0011), 0.9, 12);
      cam.anim = null;
    };

    c.addEventListener('pointerdown', onDown);
    c.addEventListener('pointermove', onMove);
    c.addEventListener('pointerup', endPointer);
    c.addEventListener('pointercancel', endPointer);
    c.addEventListener('wheel', onWheel, { passive: false });

    return () => {
      c.removeEventListener('pointerdown', onDown);
      c.removeEventListener('pointermove', onMove);
      c.removeEventListener('pointerup', endPointer);
      c.removeEventListener('pointercancel', endPointer);
      c.removeEventListener('wheel', onWheel);
    };
  }, []);

  // Resize
  useEffect(() => {
    const onResize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const W = window.innerWidth, H = window.innerHeight;
      useStore.getState().setViewport(W, H, dpr);
      const c = canvasRef.current;
      if (c) {
        c.width = W * dpr;
        c.height = H * dpr;
        c.style.width = W + 'px';
        c.style.height = H + 'px';
      }
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // Animation frame
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const STARS = _STARS;
    let lastRoster = { cam: [0, 0, 0] as number[], t: 0, dirty: true };

    const drawGlyph = (
      x: number, y: number, sz: number, col: string, kind: string, fill?: boolean,
    ) => {
      ctx.strokeStyle = col;
      ctx.fillStyle = col;
      ctx.lineWidth = 1.4;
      switch (kind) {
        case 'OP':
          ctx.beginPath();
          ctx.moveTo(x, y - sz); ctx.lineTo(x - sz * 0.9, y + sz * 0.75); ctx.lineTo(x + sz * 0.9, y + sz * 0.75);
          ctx.closePath();
          if (fill) ctx.fill(); else ctx.stroke();
          break;
        case 'UG':
          ctx.beginPath(); ctx.arc(x, y, sz * 0.85, 0, TAU); ctx.stroke();
          ctx.beginPath(); ctx.arc(x, y, sz * 0.28, 0, TAU); ctx.fill();
          break;
        case 'BR':
          ctx.beginPath();
          ctx.moveTo(x, y - sz); ctx.lineTo(x + sz * 0.8, y); ctx.lineTo(x, y + sz); ctx.lineTo(x - sz * 0.8, y);
          ctx.closePath();
          if (fill) ctx.fill(); else ctx.stroke();
          break;
        case 'DV':
          ctx.beginPath();
          ctx.moveTo(x, y - sz); ctx.lineTo(x - sz * 0.9, y + sz * 0.75); ctx.lineTo(x + sz * 0.9, y + sz * 0.75);
          ctx.closePath(); ctx.stroke();
          ctx.beginPath(); ctx.arc(x, y, sz * 0.26, 0, TAU); ctx.fill();
          break;
        case 'CL':
          ctx.beginPath();
          ctx.moveTo(x - sz * 0.8, y - sz * 0.8); ctx.lineTo(x + sz * 0.8, y + sz * 0.8);
          ctx.moveTo(x + sz * 0.8, y - sz * 0.8); ctx.lineTo(x - sz * 0.8, y + sz * 0.8);
          ctx.stroke();
          break;
        case 'TSF':
          ctx.beginPath();
          ctx.moveTo(x, y - sz); ctx.lineTo(x + sz * 0.85, y); ctx.lineTo(x, y + sz); ctx.lineTo(x - sz * 0.85, y);
          ctx.closePath(); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(x - sz * 0.4, y); ctx.lineTo(x + sz * 0.4, y); ctx.stroke();
          break;
        case 'PL':
          ctx.strokeRect(x - sz * 0.75, y - sz * 0.75, sz * 1.5, sz * 1.5);
          ctx.beginPath(); ctx.arc(x, y, sz * 0.2, 0, TAU); ctx.fill();
          break;
      }
    };

    const drawGraticule = (P: ReturnType<typeof getPalette>) => {
      const st = useStore.getState();
      ctx.strokeStyle = P.grid;
      ctx.lineWidth = 1;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      for (let lng = -180; lng < 180; lng += 15) {
        let pen = false;
        for (let lat = -88; lat <= 88; lat += 4) {
          const p = project(lat, lng, st.cam, st.W, st.H);
          if (p) {
            if (pen) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]);
            pen = true;
          } else { pen = false; }
        }
      }
      for (let lat = -75; lat <= 75; lat += 15) {
        let pen = false;
        for (let lng = -180; lng <= 180; lng += 4) {
          const p = project(lat, lng, st.cam, st.W, st.H);
          if (p) {
            if (pen) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]);
            pen = true;
          } else { pen = false; }
        }
      }
      ctx.stroke();
      ctx.globalAlpha = 1;
    };

    const drawLand = (P: ReturnType<typeof getPalette>) => {
      const st = useStore.getState();
      LAND.forEach((a, i) => {
        ctx.beginPath();
        let any = false;
        for (let k = 0; k < a.length; k += 2) {
          const p = project(a[k + 1], a[k], st.cam, st.W, st.H);
          if (p) {
            if (any) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]);
            any = true;
          } else { any = false; }
        }
        ctx.closePath();
        ctx.fillStyle = P.land === 'dyn' ? LCOL[i % LCOL.length] : P.land;
        ctx.fill();
        ctx.strokeStyle = P.coast;
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.9;
        ctx.stroke();
        ctx.globalAlpha = 1;
      });
      SEAS.forEach((a) => {
        ctx.beginPath();
        let any = false;
        for (let k = 0; k < a.length; k += 2) {
          const p = project(a[k + 1], a[k], st.cam, st.W, st.H);
          if (p) {
            if (any) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]);
            any = true;
          } else { any = false; }
        }
        ctx.closePath();
        ctx.fillStyle = P.ocean;
        ctx.fill();
      });
    };

    const drawSites = (P: ReturnType<typeof getPalette>, t: number) => {
      const st = useStore.getState();
      const zoom = st.cam.zoom;
      let vis = 0;
      for (const s of SITES) {
        s.vis = false;
        if (!siteOn(s, st)) continue;
        if (!s.tsf && !s.pl && !s.t1 && zoom < 1.7) continue;
        const p = project(s.lat, s.lng, st.cam, st.W, st.H);
        if (!p) continue;
        s.sx = p[0]; s.sy = p[1]; s.vis = true; vis++;
        const sz = (s.t1 ? 5.5 : 4.2) * (1 + Math.min(1.1, (zoom - 1) * 0.3));
        const col = markerColor(s, st, P);
        const kind = kindOf(s);
        if (s.t1) { ctx.save(); ctx.shadowColor = col; ctx.shadowBlur = 7; }
        drawGlyph(s.sx, s.sy, sz, col, kind, s.t1 && kind === 'BR');
        if (s.t1) ctx.restore();
        if (s.tsf && (s.haz === 'FAILED' || s.haz === 'EXTREME')) {
          const a = 0.35 + 0.3 * Math.sin(t * 0.004 + hash(s.id));
          ctx.strokeStyle = hexA(HAZCOL[s.haz], a);
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(s.sx, s.sy, sz * 2.1, 0, TAU);
          ctx.stroke();
        }
      }
      st.setContactCount(vis);
    };

    const drawHazRings = (P: ReturnType<typeof getPalette>, t: number) => {
      const st = useStore.getState();
      if (!st.track || st.track.tsf || st.track.pl) return;
      if (st.cam.zoom < 2.5) return;
      const s = st.track;
      const p = project(s.lat, s.lng, st.cam, st.W, st.H);
      if (!p) return;
      const kmPx = globeR(st.W, st.H, st.cam) / 6371;
      [40, 80, 160].forEach((km) => {
        ctx.strokeStyle = hexA(P.accent, 0.28);
        ctx.setLineDash([3, 5]);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(p[0], p[1], km * kmPx, 0, TAU);
        ctx.stroke();
      });
      ctx.setLineDash([]);
      ctx.fillStyle = hexA(P.accent, 0.7);
      ctx.font = '9px "IBM Plex Mono",monospace';
      ctx.fillText('160 KM', p[0] + 160 * kmPx + 3, p[1] - 3);
    };

    const drawQuakes = (t: number) => {
      const st = useStore.getState();
      const now = performance.now();
      const arr = st.quakes;
      for (let i = arr.length - 1; i >= 0; i--) {
        const q = arr[i];
        const age = now - q.t0;
        if (age > 5200) continue;
        const p = project(q.lat, q.lng, st.cam, st.W, st.H);
        if (!p) continue;
        const pr = age / 5200;
        ctx.strokeStyle = hexA('#5bd6dd', 1 - pr);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(p[0], p[1], 4 + pr * 44, 0, TAU);
        ctx.stroke();
        ctx.strokeStyle = hexA('#5bd6dd', (1 - pr) * 0.5);
        ctx.beginPath();
        ctx.arc(p[0], p[1], 4 + pr * 26, 0, TAU);
        ctx.stroke();
        ctx.fillStyle = hexA('#5bd6dd', 0.9);
        ctx.font = '9px "IBM Plex Mono",monospace';
        ctx.fillText('ML ' + q.mag, p[0] + 8, p[1] - 8);
      }
    };

    const drawBlips = (t: number) => {
      const st = useStore.getState();
      const now = performance.now();
      const arr = st.blips;
      for (let i = arr.length - 1; i >= 0; i--) {
        const b = arr[i];
        const age = now - b.t0;
        if (age > 8000) continue;
        if (!b.s) continue;
        const p = project(b.s.lat, b.s.lng, st.cam, st.W, st.H);
        if (!p) continue;
        const pr = age / 8000;
        const col = b.sev === 'alert' ? '#ff5f56' : b.sev === 'warn' ? '#ffb454' : '#5bd6dd';
        ctx.strokeStyle = hexA(col, 1 - pr);
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(p[0], p[1], 5 + pr * 36, 0, TAU);
        ctx.stroke();
      }
    };

    const drawLabels = (P: ReturnType<typeof getPalette>) => {
      const st = useStore.getState();
      const zoom = st.cam.zoom;
      let count = 0;
      const sorted = SITES.filter((s) => s.vis).sort((a, b) => (b.t1 ? 1 : 0) - (a.t1 ? 1 : 0));
      ctx.font = '10px "IBM Plex Mono",monospace';
      for (const s of sorted) {
        if (count > 72) break;
        const want = s === st.track || st.labels || (s.t1 && zoom >= 2.0) || (!s.t1 && zoom >= 2.8);
        if (!want) continue;
        const label = s.name.toUpperCase();
        const w = ctx.measureText(label).width;
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.fillRect((s.sx ?? 0) + 9, (s.sy ?? 0) - 7, w + 6, 13);
        ctx.fillStyle = s.tsf ? HAZCOL[s.haz] : P.text;
        ctx.globalAlpha = 0.9;
        ctx.fillText(label, (s.sx ?? 0) + 12, (s.sy ?? 0) + 3);
        ctx.globalAlpha = 1;
        count++;
      }
    };

    const drawDetections = (P: ReturnType<typeof getPalette>) => {
      const st = useStore.getState();
      if (!st.detect) return;
      const list = SITES.filter((s) => s.vis)
        .map((s) => [s as (typeof SITES)[number], ((s.sx ?? 0) - st.W / 2) ** 2 + ((s.sy ?? 0) - st.H / 2) ** 2] as const)
        .sort((a, b) => a[1] - b[1])
        .slice(0, 36);
      ctx.font = '9px "IBM Plex Mono",monospace';
      for (const [s] of list) {
        const label = s.name.toUpperCase();
        const bw = Math.max(30, label.length * 6.4 + 22);
        const bh = 24;
        const x = (s.sx ?? 0) - bw / 2 - 6;
        const y = (s.sy ?? 0) - bh / 2 - 2;
        ctx.strokeStyle = hexA(P.accent, 0.9);
        ctx.lineWidth = 1.2;
        const c = 7;
        ctx.beginPath();
        ctx.moveTo(x, y + c); ctx.lineTo(x, y); ctx.lineTo(x + c, y);
        ctx.moveTo(x + bw - c, y); ctx.lineTo(x + bw, y); ctx.lineTo(x + bw, y + c);
        ctx.moveTo(x + bw, y + bh - c); ctx.lineTo(x + bw, y + bh); ctx.lineTo(x + bw - c, y + bh);
        ctx.moveTo(x + c, y + bh); ctx.lineTo(x, y + bh); ctx.lineTo(x, y + bh - c);
        ctx.stroke();
        ctx.fillStyle = hexA(P.accent, 0.95);
        ctx.fillText(s.code + ' ▓ ' + (92 + hash(s.id) % 8) + '%', x, y - 4);
      }
    };

    const drawTrackedReticle = (P: ReturnType<typeof getPalette>, t: number) => {
      const st = useStore.getState();
      const s = st.track;
      if (!s) return;
      const p = project(s.lat, s.lng, st.cam, st.W, st.H);
      if (!p) {
        const d = rawDir(s.lat, s.lng, st.cam);
        const ang = Math.atan2(-d[1], d[0]);
        const R = globeR(st.W, st.H, st.cam);
        const x = st.W / 2 + Math.cos(ang) * (R + 6);
        const y = st.H / 2 + Math.sin(ang) * (R + 6);
        ctx.save();
        ctx.translate(x, y); ctx.rotate(ang);
        ctx.strokeStyle = P.accent; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, 0); ctx.lineTo(-12, -7); ctx.lineTo(-12, 7); ctx.closePath(); ctx.stroke();
        ctx.restore();
        ctx.fillStyle = P.accent;
        ctx.font = '9px "IBM Plex Mono",monospace';
        ctx.fillText(s.name.toUpperCase(), x - 30, y + 18);
        return;
      }
      const r = 15 + 3 * Math.sin(t * 0.003);
      ctx.save();
      ctx.strokeStyle = P.accent; ctx.lineWidth = 1.4;
      ctx.setLineDash([7, 6]);
      ctx.lineDashOffset = -t * 0.02;
      ctx.beginPath();
      ctx.arc(p[0], p[1], r + 5, 0, TAU); ctx.stroke();
      ctx.setLineDash([]);
      const B = r + 14;
      const c = 6;
      ctx.beginPath();
      [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach((pair) => {
        const ux = pair[0], uy = pair[1];
        ctx.moveTo(p[0] + ux * B - ux * c, p[1] + uy * B);
        ctx.lineTo(p[0] + ux * B, p[1] + uy * B);
        ctx.lineTo(p[0] + ux * B, p[1] + uy * B - uy * c);
      });
      ctx.stroke();
      ctx.strokeStyle = hexA(P.accent, 0.16);
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, p[1]); ctx.lineTo(p[0] - B, p[1]);
      ctx.moveTo(p[0] + B, p[1]); ctx.lineTo(st.W, p[1]);
      ctx.moveTo(p[0], 0); ctx.lineTo(p[0], p[1] - B);
      ctx.moveTo(p[0], p[1] + B); ctx.lineTo(p[0], st.H);
      ctx.stroke();
      ctx.font = '10px "IBM Plex Mono",monospace';
      const tag = '◤ ' + s.name.toUpperCase() + ' ' + s.code;
      const wtag = ctx.measureText(tag).width;
      ctx.fillStyle = 'rgba(0,0,0,.6)';
      ctx.fillRect(p[0] + B + 4, p[1] - 9, wtag + 8, 14);
      ctx.fillStyle = P.accent;
      ctx.fillText(tag, p[0] + B + 8, p[1] + 2);
      ctx.restore();
    };

    function getPalette() {
      const st = useStore.getState();
      return STYLES[st.style];
    }

    const drawGlobe = (t: number) => {
      const st = useStore.getState();
      const P = STYLES[st.style];
      const dpr = st.dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = P.bg;
      ctx.fillRect(0, 0, st.W, st.H);
      ctx.fillStyle = P.star;
      STARS.forEach((s) => {
        ctx.globalAlpha = (0.25 + 0.75 * Math.abs(Math.sin(t * 0.0004 + s[2]))) * 0.8;
        ctx.fillRect(s[0] * st.W, s[1] * st.H, 1.6, 1.6);
      });
      ctx.globalAlpha = 1;
      const R = globeR(st.W, st.H, st.cam);
      const cx = st.W / 2;
      const cy = st.H / 2;
      const g = ctx.createRadialGradient(cx, cy, R * 0.94, cx, cy, R * 1.13);
      g.addColorStop(0, hexA(P.glow, 0.25));
      g.addColorStop(1, hexA(P.glow, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, R * 1.13, 0, TAU);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.fillStyle = P.ocean;
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.clip();
      if (st.grid) drawGraticule(P);
      drawLand(P);
      drawHazRings(P, t);
      ctx.restore();
      ctx.save();
      ctx.shadowColor = P.glow;
      ctx.shadowBlur = 16;
      ctx.strokeStyle = hexA(P.glow, 0.8);
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.stroke();
      ctx.restore();
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R + 16, 0, TAU);
      ctx.clip();
      drawSites(P, t);
      drawQuakes(t);
      drawBlips(t);
      drawLabels(P);
      drawDetections(P);
      ctx.restore();
      drawTrackedReticle(P, t);
    };

    const updateDom = (t: number) => {
      // Throttle DOM updates via React state
      const st = useStore.getState();
      if (t - lastRoster.t < 250) return;
      lastRoster.t = t;
      const cl = centerLatLon(st.cam);
      const alt = Math.round(19000 / Math.pow(st.cam.zoom, 1.1));
      const latS = (cl[0] >= 0 ? '' : '−') + Math.abs(cl[0]).toFixed(1) + '°' + (cl[0] >= 0 ? 'N' : 'S');
      const lonS = (cl[1] >= 0 ? '' : '−') + Math.abs(cl[1]).toFixed(1) + '°' + (cl[1] >= 0 ? 'E' : 'W');
      const hudEl = document.getElementById('hudcenter');
      if (hudEl && st.hud) {
        hudEl.innerHTML =
          'VIEW <b>' + latS + ' ' + lonS + '</b> · ALT <b>' + fmtN(alt) + ' KM</b> · CONTACTS <b>' +
          st.contactCount + '</b> · STYLE <b>' + STYLES[st.style].name + '</b>' +
          (st.track ? ' · TRACK <b>' + st.track.name.toUpperCase() + '</b>' : '');
      }
      const hudline = document.getElementById('hudline');
      if (hudline) {
        hudline.innerHTML =
          'MRDS ' + 91 + ' <b>✓</b> · GTP ' + 11 + ' <b>✓</b> · PLANTS ' + 7 +
          ' <b>✓</b> · WIRE <b>SIM</b> · ' + Math.floor(st.fps) + ' FPS';
      }
      const clockEl = document.getElementById('clock');
      if (clockEl) {
        const d = new Date();
        clockEl.textContent = d.toISOString().slice(11, 19) + ' UTC';
      }
      // Roster
      const cc = [st.cam.yaw, st.cam.tilt, st.cam.zoom];
      const dirtyRoster = lastRoster.dirty;
      if (
        dirtyRoster ||
        Math.abs(cc[0] - lastRoster.cam[0]) > 0.02 ||
        Math.abs(cc[1] - lastRoster.cam[1]) > 0.02 ||
        Math.abs(cc[2] - lastRoster.cam[2]) > 0.15
      ) {
        lastRoster.cam = cc;
        lastRoster.dirty = false;
        if (st.mode === 'globe') renderRoster();
      }
    };

    function renderRoster() {
      const st = useStore.getState();
      const refPt = st.track && st.cam.zoom > 2 ? st.track : null;
      let list: typeof SITES;
      if (refPt) {
        list = SITES.filter((s) => siteOn(s, st) && haversine(s, refPt) < 500);
      } else {
        list = SITES.filter((s) => s.vis);
      }
      const ref = refPt ?? { lat: st.cam.tilt / (Math.PI / 180), lng: ((-st.cam.yaw) / (Math.PI / 180) + 540) % 360 - 180 };
      list.sort((a, b) => haversine(a, ref) - haversine(b, ref));
      list = list.slice(0, 30) as typeof SITES;
      st.setRoster(list, 0);
      const subEl = document.getElementById('roster-sub');
      if (subEl) {
        subEl.textContent = refPt
          ? '≤ 500 KM OF ' + st.track!.name.toUpperCase()
          : 'IN VIEW · ' + st.contactCount + ' CONTACTS';
      }
      const rosterEl = document.getElementById('roster');
      if (rosterEl) {
        rosterEl.innerHTML =
          list
            .map((s) => {
              const col = s.tsf
                ? HAZCOL[s.haz]
                : s.pl
                ? '#5bd6dd'
                : COMMS[s.comms[0]].col;
              const d = haversine(s, ref);
              return (
                '<div class="rrow ' + (s === st.track ? 'trk' : '') + '" data-id="' + s.id + '">' +
                '<span class="rg" style="color:' + col + '">' + GLY[kindOf(s)] + '</span>' +
                '<span class="rn">' + s.name.toUpperCase() + '</span>' +
                '<span class="rc">' + (s.tsf ? 'TSF' : s.pl ? 'PL' : s.comms.join('·')) + '</span>' +
                '<span class="rd">' + (d < 10 ? '—' : Math.round(d) + ' km') + '</span></div>'
              );
            })
            .join('') || '<div class="c-dim" style="padding:6px 0">NO CONTACTS — ZOOM IN OR ENABLE LAYERS</div>';
      }
    }

    const frame = (t: number) => {
      rafRef.current = requestAnimationFrame(frame);
      const st = useStore.getState();
      const dt = Math.min(64, t - lastTRef.current);
      lastTRef.current = t;
      // FPS
      const fpsState = fpsRef.current;
      fpsState.frames++;
      if (t - fpsState.lastFpsT > 1000) {
        fpsState.fps = (fpsState.frames * 1000) / (t - fpsState.lastFpsT);
        fpsState.frames = 0;
        fpsState.lastFpsT = t;
        st.setFps(fpsState.fps);
      }
      try {
        stepCam(st.cam, dt, {
          spin: st.spin,
          mode: st.mode,
          tour: st.tour,
          lastPointer: st.lastPointer,
        });
        if (st.mode === 'pit') return; // Pit view draws its own canvas
        drawGlobe(t);
        updateDom(t);
      } catch (err) {
        st.pushConsole('FRAME ERROR: ' + (err instanceof Error ? err.message : String(err)), 'c-err');
      }
    };

    // Click on roster delegation
    const onRosterClick = (e: MouseEvent) => {
      const row = (e.target as HTMLElement).closest('.rrow') as HTMLElement | null;
      if (!row) return;
      const s = SITES.find((x) => x.id === row.dataset.id);
      if (s) useStore.getState().trackSite(s);
    };
    const rosterEl = document.getElementById('roster');
    rosterEl?.addEventListener('click', onRosterClick);

    rafRef.current = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(rafRef.current);
      rosterEl?.removeEventListener('click', onRosterClick);
    };
  }, []);

  // Keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return;
      const k = e.key.toLowerCase();
      const s = useStore.getState();
      if (k >= '1' && k <= '7') {
        s.setStyle(['normal','crt','nvg','ironbow','whitehot','noir','spectral'][+k - 1] as never);
      } else if (k === 'd') { s.toggleLayer('detect'); s.showToast('DETECTION ' + (s.detect ? 'ON' : 'OFF')); }
      else if (k === 'l') { s.toggleLayer('labels'); s.showToast('LABELS ' + (s.labels ? 'FORCED' : 'AUTO')); }
      else if (k === 'h') { s.toggleLayer('hud'); }
      else if (k === 't') {
        // step contact
        const list = s.rosterList;
        if (!list.length) return;
        const idx = (s.rosterIdx + 1 + list.length) % list.length;
        s.setRoster(list, idx);
        s.trackSite(list[idx]);
      }
      else if (k === 'p') { if (s.mode === 'pit') s.setMode('globe'); else if (s.track) s.setMode('pit'); else s.showToast('TRACK A SITE FIRST'); }
      else if (k === 'g') {
        if (s.tour) endTour(s);
        flyTo(s.cam, 15, 0, 1, 1600);
        if (!s.spin) s.toggleLayer('spin');
        s.showToast('RESET ▸ FULL GLOBE');
      }
      else if (k === '/') {
        e.preventDefault();
        const cin = document.getElementById('cin') as HTMLInputElement | null;
        cin?.focus();
      }
      else if (k === 'escape') {
        if (s.mode === 'pit') s.setMode('globe');
        else if (s.tour) endTour(s);
        else if (s.track) s.trackSite(null);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <canvas
      id="globe"
      ref={canvasRef}
      className="fixed inset-0 cursor-crosshair touch-none"
      style={{ touchAction: 'none' }}
    />
  );
}

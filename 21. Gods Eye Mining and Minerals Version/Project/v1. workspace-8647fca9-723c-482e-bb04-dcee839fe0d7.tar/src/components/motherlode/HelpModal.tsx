'use client';

import { useEffect, useState } from 'react';

export default function HelpModal() {
  const [open, setOpen] = useState(false);

  // Listen for POWER UP button clicks via custom event
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener('open-help', handler);
    return () => window.removeEventListener('open-help', handler);
  }, []);

  return (
    <>
      {open && (
        <div
          id="modal"
          className="fixed inset-0 z-[460] bg-[rgba(0,0,0,0.75)] flex items-center justify-center"
          onClick={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
        >
          <div className="mbox w-[min(760px,94vw)] max-h-[86vh] overflow-y-auto bg-[var(--panel)] border border-[var(--brd2)] pb-4">
            <h2 className="font-head tracking-[0.2em] text-[15px] text-[var(--acc)] px-5 py-3.5 border-b border-[var(--brd)] flex justify-between">
              <span>SOURCES &amp; REGISTER</span>
              <button
                onClick={() => setOpen(false)}
                className="text-[var(--dim)] hover:text-[var(--acc)]"
              >
                ✕ CLOSE
              </button>
            </h2>
            <div className="mbody px-5 py-4 text-[11.5px] leading-[1.7] text-[var(--txt)]">
              <p>
                <b>KEYLESS BOOT.</b> This build runs entirely client-side, offline. No accounts, no keys, no network. In a full deployment you would bolt on live feeds — USGS MRDS, Mindat, the Global Tailings Portal, broker wires. Every layer here is a pattern you point at your own data.
              </p>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">LAYERS &amp; SOURCES</h3>
              <table className="w-full border-collapse text-[10.5px] my-1.5">
                <tbody>
                  <Row a="Mines & commodities" b="91 static sites, compiled from public disclosures (USGS MRDS, Mindat, company reports)" c="LOCAL" color="var(--grn)" />
                  <Row a="Tailings facilities" b="11 records in the style of Global Tailings Portal disclosures" c="LOCAL" color="var(--grn)" />
                  <Row a="Processing plants" b="7 public-register nodes" c="LOCAL" color="var(--grn)" />
                  <Row a="Commodity wire / prices" b="Random-walk simulation around plausible levels" c="SIM" color="var(--acc)" />
                  <Row a="Incidents & seismicity" b="Synthesized locally for demonstration" c="SIM" color="var(--acc)" />
                  <Row a="Basemap" b="Stylized vector globe — deliberately not survey-grade" c="LOCAL" color="var(--grn)" />
                </tbody>
              </table>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">THE BASEMAP LADDER</h3>
              <table className="w-full border-collapse text-[10.5px] my-1.5">
                <tbody>
                  <Row a="🟢 You have nothing" b="This vector globe — works offline, zero cost" />
                  <Row a="🟡 Cesium ion token" b="Photorealistic 3D tiles + world terrain (not wired in this build)" />
                </tbody>
              </table>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">WHAT IT ACTUALLY COSTS</h3>
              <p>$0. It is one file. Prices, telemetry and alerts are simulated so it stays that way.</p>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">THE LINE</h3>
              <p>
                This console models sites, infrastructure, and public data. It does not build features for named-person search or tracking individuals — <b>people are not a query type here.</b>
              </p>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">IMPORTANT</h3>
              <p className="text-[var(--dim)]">
                MOTHERLODE is an exploratory visualization of public and third-party data. Positions are approximate, figures may be dated, and simulated feeds are labeled as such. Do not use it for investment decisions, operational planning, or safety-critical purposes. Verify with authoritative sources. Static datasets carry their own terms; code MIT.
              </p>
              <h3 className="text-[11px] tracking-[0.2em] text-[var(--txt)] mt-4 mb-1.5">KEYBOARD</h3>
              <p>
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">1–7</kbd> sensors ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">D</kbd> detection ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">L</kbd> labels ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">H</kbd> HUD ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">T</kbd> next contact ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">P</kbd> pit mode ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">/</kbd> console ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">Esc</kbd> exit ·{' '}
                <kbd className="border border-[var(--brd2)] px-1.5 text-[10px] text-[var(--acc)]">G</kbd> reset
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Row({
  a, b, c, color,
}: {
  a: string;
  b: string;
  c?: string;
  color?: string;
}) {
  return (
    <tr>
      <td className="border border-[var(--brd)] px-2.5 py-1.5 align-top whitespace-nowrap text-[var(--acc)]">{a}</td>
      <td className="border border-[var(--brd)] px-2.5 py-1.5 align-top">{b}</td>
      {c && (
        <td className="border border-[var(--brd)] px-2.5 py-1.5 align-top" style={{ color }}>
          {c}
        </td>
      )}
    </tr>
  );
}

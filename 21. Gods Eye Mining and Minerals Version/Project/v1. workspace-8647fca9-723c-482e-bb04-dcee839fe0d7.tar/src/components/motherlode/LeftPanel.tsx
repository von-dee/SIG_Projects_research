'use client';

import { useStore } from '@/lib/motherlode/store';
import { COMMS, MINES, TSFS, PLANTS } from '@/lib/motherlode/data';
import { CGROUPS } from '@/lib/motherlode/constants';
import { endTour } from '@/lib/motherlode/commands';
import { flyTo } from '@/lib/motherlode/geometry';
import type { Comm } from '@/lib/motherlode/types';
import { TOURS } from '@/lib/motherlode/constants';

export default function LeftPanel() {
  const comm = useStore((s) => s.comm);
  const tsf = useStore((s) => s.tsf);
  const plant = useStore((s) => s.plant);
  const detect = useStore((s) => s.detect);
  const labels = useStore((s) => s.labels);
  const grid = useStore((s) => s.grid);
  const spin = useStore((s) => s.spin);
  const hud = useStore((s) => s.hud);
  const incidents = useStore((s) => s.incidents);
  const seis = useStore((s) => s.seis);
  const toggleComm = useStore((s) => s.toggleComm);
  const toggleLayer = useStore((s) => s.toggleLayer);
  const setCommAll = useStore((s) => s.setCommAll);

  const counts: Record<string, number> = {};
  MINES.forEach((m) => m.comms.forEach((c) => (counts[c] = (counts[c] || 0) + 1)));

  return (
    <aside
      id="left"
      className="panel fixed top-[58px] left-3 w-[292px] bg-[var(--panel)] border border-[var(--brd)] z-40 backdrop-blur-[5px] flex flex-col max-h-[calc(100vh-152px)]"
    >
      <div className="ph px-3 py-1.5 font-head text-[11px] tracking-[0.18em] border-b border-[var(--brd)] text-[var(--acc)]">
        SENSORS &amp; LAYERS
      </div>
      <div className="pc overflow-y-auto px-3 py-2 flex-1 min-h-0">
        <div className="sect text-[9px] tracking-[0.22em] text-[var(--dim)] my-3 mt-0.5">DISPLAY</div>
        <LayerRow label="Detection Mesh" hint="D" on={detect} onClick={() => toggleLayer('detect')} />
        <LayerRow label="Force Labels" hint="L" on={labels} onClick={() => toggleLayer('labels')} />
        <LayerRow label="Graticule" hint="" on={grid} onClick={() => toggleLayer('grid')} />
        <LayerRow label="Auto-Spin" hint="" on={spin} onClick={() => toggleLayer('spin')} />
        <LayerRow label="HUD Readout" hint="H" on={hud} onClick={() => toggleLayer('hud')} />

        <div className="sect text-[9px] tracking-[0.22em] text-[var(--dim)] my-3">COMMODITY LAYERS</div>
        <div className="opbtns flex gap-1.5 flex-wrap my-2">
          <button
            onClick={() => setCommAll(true)}
            className="flex-1 text-[9px] border border-[var(--brd2)] text-[var(--txt)] px-2 py-0.5 tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            ALL ON
          </button>
          <button
            onClick={() => setCommAll(false)}
            className="flex-1 text-[9px] border border-[var(--brd2)] text-[var(--txt)] px-2 py-0.5 tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            ALL OFF
          </button>
        </div>
        {CGROUPS.map(([title, keys]) => (
          <div key={title}>
            <div className="sect text-[9px] tracking-[0.22em] text-[var(--dim)] my-3">{title}</div>
            {keys.map((k) => (
              <CommRow
                key={k}
                comm={k}
                count={counts[k] || 0}
                on={comm[k]}
                onClick={() => toggleComm(k)}
              />
            ))}
          </div>
        ))}

        <div className="sect text-[9px] tracking-[0.22em] text-[var(--dim)] my-3">HAZARDS &amp; INFRASTRUCTURE</div>
        <LayerRow
          label="Tailings Facilities"
          hint={String(TSFS.length)}
          on={tsf}
          onClick={() => toggleLayer('tsf')}
          colorSwatch="#ff8a3c"
        />
        <div className="legend flex gap-2.5 flex-wrap text-[9px] text-[var(--dim)] my-1">
          <span><i className="inline-block w-[7px] h-[7px] mr-1" style={{ background: '#ff5f56' }} />FAILED</span>
          <span><i className="inline-block w-[7px] h-[7px] mr-1" style={{ background: '#ff8a3c' }} />EXTREME</span>
          <span><i className="inline-block w-[7px] h-[7px] mr-1" style={{ background: '#ffb454' }} />HIGH</span>
          <span><i className="inline-block w-[7px] h-[7px] mr-1" style={{ background: '#5bd6dd' }} />RIVERINE</span>
        </div>
        <LayerRow label="Incident Blips" hint="WIRE" on={incidents} onClick={() => toggleLayer('incidents')} />
        <LayerRow label="Seismicity (SIM)" hint="" on={seis} onClick={() => toggleLayer('seis')} />
        <LayerRow
          label="Processing Plants"
          hint={String(PLANTS.length)}
          on={plant}
          onClick={() => toggleLayer('plant')}
          colorSwatch="#5bd6dd"
        />

        <div className="sect text-[9px] tracking-[0.22em] text-[var(--dim)] my-3">OPERATIONS</div>
        <div className="opbtns flex gap-1.5 flex-wrap my-2">
          <button
            onClick={() => {
              const s = useStore.getState();
              if (s.tour) endTour(s);
              flyTo(s.cam, 15, 0, 1, 1600);
              if (!s.spin) s.toggleLayer('spin');
              s.showToast('RESET ▸ FULL GLOBE');
            }}
            className="flex-1 text-[9px] border border-[var(--brd2)] text-[var(--txt)] px-2 py-0.5 tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            RESET GLOBE
          </button>
          <button
            onClick={() => {
              const s = useStore.getState();
              const tourNames = Object.keys(TOURS);
              // Pick next tour in rotation
              const next = tourNames[(tourNames.indexOf(s.tour?.name ?? '') + 1) % tourNames.length] ?? tourNames[0];
              s.pushConsole('TOUR ▸ ' + next.toUpperCase(), 'c-ok');
              // Trigger via command parser
              import('@/lib/motherlode/commands').then(({ runCommand }) => runCommand('tour ' + next));
            }}
            className="acc flex-1 text-[9px] border border-[var(--acc)] text-[var(--acc)] px-2 py-0.5 tracking-wider hover:bg-[rgba(255,180,84,0.06)]"
          >
            TOUR ▸
          </button>
        </div>
        <div className="mini text-[9px] text-[var(--dim)] leading-[1.5] mt-2.5 border-t border-[var(--brd)] pt-2">
          BASEMAP: STYLIZED VECTOR GLOBE (LOCAL)<br />
          DEPOSIT DATA: PUBLIC SOURCES · APPROX.<br />
          WIRE / PRICES / SEISMIC: SIMULATED<br />
          <b style={{ color: 'var(--grn)' }}>NO DEPOSIT LEFT BEHIND.</b>
        </div>
      </div>
    </aside>
  );
}

function LayerRow({
  label, hint, on, onClick, colorSwatch,
}: {
  label: string;
  hint: string;
  on: boolean;
  onClick: () => void;
  colorSwatch?: string;
}) {
  return (
    <div
      onClick={onClick}
      className={
        'lrow flex items-center gap-2 py-0.5 cursor-pointer tracking-[0.05em] ' +
        (on ? '' : 'off opacity-35')
      }
    >
      <span className="tgl w-2.5 h-2.5 border flex-none relative" style={{ borderColor: on ? 'var(--acc)' : 'var(--dim)' }}>
        {on && <span className="absolute inset-[2px] bg-[var(--acc)]" />}
      </span>
      {colorSwatch && (
        <span className="sw w-2 h-2 flex-none" style={{ background: colorSwatch }} />
      )}
      <span className="ln flex-1 text-[11px] uppercase">{label}</span>
      <span className="cnt text-[var(--dim)] text-[10px]">{hint}</span>
    </div>
  );
}

function CommRow({
  comm, count, on, onClick,
}: {
  comm: Comm;
  count: number;
  on: boolean;
  onClick: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className={
        'lrow flex items-center gap-2 py-0.5 cursor-pointer tracking-[0.05em] ' +
        (on ? '' : 'off opacity-35')
      }
    >
      <span className="tgl w-2.5 h-2.5 border flex-none relative" style={{ borderColor: on ? 'var(--acc)' : 'var(--dim)' }}>
        {on && <span className="absolute inset-[2px] bg-[var(--acc)]" />}
      </span>
      <span className="sw w-2 h-2 flex-none" style={{ background: COMMS[comm].col }} />
      <span className="ln flex-1 text-[11px] uppercase">{COMMS[comm].name}</span>
      <span className="cnt text-[var(--dim)] text-[10px]">{count}</span>
    </div>
  );
}

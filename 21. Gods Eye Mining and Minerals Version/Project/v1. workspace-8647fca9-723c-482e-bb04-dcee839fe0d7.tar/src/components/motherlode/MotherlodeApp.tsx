'use client';

import { useEffect } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { MINES, TSFS, PRICES } from '@/lib/motherlode/data';
import { SITES } from '@/lib/motherlode/sites';
import { fmtN } from '@/lib/motherlode/constants';
import Globe from './Globe';
import PitView from './PitView';
import TopBar from './TopBar';
import LeftPanel from './LeftPanel';
import RightPanel from './RightPanel';
import StyleBar from './StyleBar';
import Console from './Console';
import Ticker from './Ticker';
import TourBar from './TourBar';
import Splash from './Splash';
import HelpModal from './HelpModal';
import Toast from './Toast';
import Overlays from './Overlays';

export default function MotherlodeApp() {
  const pushAlert = useStore((s) => s.pushAlert);
  const pushQuake = useStore((s) => s.pushQuake);
  const seis = useStore((s) => s.seis);
  const pushConsole = useStore((s) => s.pushConsole);

  // Seed initial wire alerts
  useEffect(() => {
    pushAlert('info', 'BOOT — wire feed armed. All indicators SIMULATED locally.');
    pushAlert('info', 'WIRE: NdPr oxide +1.8% — magnet chain tightness persists. (SIM)');
    pushAlert('warn', 'TSF WATCH — Córrego do Feijão Dam I: anniversary inspections logged. Public disclosure.', TSFS[0]);
    pushAlert('info', 'BLAST FIRED — Chuquicamata: 96 holes, 212 t. (SIM)', SITES.find((s) => s.id === 'chuqui'));
    pushConsole('MOTHERLODE online. Keyless boot — 91 mines, 11 tailings records, 7 plants. Try "help", or just click a contact.', 'c-ok');
    pushConsole('Console: "track grasberg", "show lithium", "nvg", "tour copper", "pit", "fly to chile". Keyboard: 1-7 sensors · D detection · P pit · T next contact · / console.', 'c-dim');
  }, []);

  // Periodic alert generation
  useEffect(() => {
    const genAlert = () => {
      const s = useStore.getState();
      const r = Math.random();
      const m = MINES[Math.floor(Math.random() * MINES.length)];
      if (r < 0.2) {
        s.pushAlert('info', `BLAST FIRED — ${m.name}: ${20 + Math.floor(Math.random() * 140)} holes, ${40 + (Math.random() * 300 | 0)} t agent. <span class="c-dim">(SIM)</span>`, m);
      } else if (r < 0.38) {
        s.pushAlert('warn', `SEISMIC ML ${(1.8 + Math.random() * 1.4).toFixed(1)} — within 3 km of ${m.name} workings. Modeled event. <span class="c-dim">(SIM)</span>`, m);
      } else if (r < 0.52) {
        const f = TSFS[Math.floor(Math.random() * TSFS.length)];
        s.pushAlert('warn', `TSF ADVISORY — piezometers trending high at ${f.name} (${f.haz}). <span class="c-dim">(SIM)</span>`, f);
      } else if (r < 0.66) {
        const p = PRICES[Math.floor(Math.random() * PRICES.length)];
        const d = p.val >= p.prev;
        s.pushAlert('info', `WIRE: ${p.n} ${d ? '▲' : '▼'} ${Math.abs(((p.val - p.prev) / p.prev) * 100).toFixed(2)}% — ${fmtN(p.val)} ${p.u}. <span class="c-dim">(SIM)</span>`);
      } else if (r < 0.8) {
        s.pushAlert('info', `PRODUCTION — ${m.name}: quarterly report reconciled ${Math.random() < 0.5 ? 'above' : 'below'} guidance. Public filings.`, m);
      } else if (r < 0.9) {
        s.pushAlert('alert', `SAFETY DRILL — ${m.name}: emergency exercise, hoist rope inspection. Zero-harm protocol. <span class="c-dim">(SIM)</span>`, m);
      } else {
        s.pushAlert('info', `PERMIT — ${m.name}: compliance register updated. Public record.`);
      }
    };
    const id = setInterval(genAlert, 8000);
    return () => clearInterval(id);
  }, []);

  // Periodic seismic events
  useEffect(() => {
    const id = setInterval(() => {
      if (useStore.getState().seis && Math.random() < 0.8) {
        useStore.getState().pushQuake();
      }
    }, 9000);
    return () => clearInterval(id);
  }, [seis]);

  return (
    <div className="motherlode-root fixed inset-0 overflow-hidden select-none">
      <Globe />
      <PitView />
      <TopBar />
      <LeftPanel />
      <RightPanel />
      <StyleBar />
      <Console />
      <Ticker />
      <TourBar />
      <Toast />
      <HelpModal />
      <Overlays />
      <Splash />
    </div>
  );
}

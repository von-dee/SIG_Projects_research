'use client';

export default function Overlays() {
  return (
    <>
      <div
        id="scan"
        className="fixed inset-0 z-[900] pointer-events-none"
        style={{
          opacity: 'var(--scan)',
          background:
            'repeating-linear-gradient(0deg, rgba(0,0,0,0.55) 0 1px, transparent 1px 3px)',
        }}
      />
      <div
        id="vig"
        className="fixed inset-0 z-[890] pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.55) 100%)',
        }}
      />
    </>
  );
}

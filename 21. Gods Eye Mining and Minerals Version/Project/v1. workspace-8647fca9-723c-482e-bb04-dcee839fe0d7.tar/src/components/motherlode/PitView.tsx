'use client';

import { useEffect, useRef } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { STYLES } from '@/lib/motherlode/styles';
import { STARS } from './stars';
import { TAU, hexA, hash, mix, lerp, clamp, D2R } from '@/lib/motherlode/constants';
import { POND_COLS } from '@/lib/motherlode/constants';
import { COMMS } from '@/lib/motherlode/data';
import { HAZCOL } from '@/lib/motherlode/constants';

export default function PitView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<[number, number]>([0, 0]);
  const rafRef = useRef<number>(0);

  // Mouse movement (parallax)
  useEffect(() => {
    const pit = document.getElementById('pit');
    if (!pit) return;
    const onMove = (e: PointerEvent) => {
      const st = useStore.getState();
      mouseRef.current = [e.clientX - st.W / 2, e.clientY - st.H / 2];
    };
    pit.addEventListener('pointermove', onMove);
    return () => pit.removeEventListener('pointermove', onMove);
  }, []);

  // Resize
  useEffect(() => {
    const onResize = () => {
      const st = useStore.getState();
      const c = canvasRef.current;
      if (!c) return;
      c.width = st.W * st.dpr;
      c.height = st.H * st.dpr;
      c.style.width = st.W + 'px';
      c.style.height = st.H + 'px';
    };
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const pctx = c.getContext('2d');
    if (!pctx) return;

    const ridgeLine = (cx: number, cy: number, R: number, seed: number) => {
      pctx.beginPath();
      const y0 = cy - R * 0.55;
      pctx.moveTo(cx - R * 1.9, cy - R * 0.6);
      for (let i = 0; i <= 24; i++) {
        const x = cx - R * 1.9 + (i / 24) * R * 3.8;
        pctx.lineTo(x, y0 - Math.abs(Math.sin(i * 1.7 + seed) * R * 0.07));
      }
      pctx.lineTo(cx + R * 1.9, cy);
      pctx.lineTo(cx - R * 1.9, cy);
      pctx.closePath();
      pctx.fillStyle = 'rgba(6,12,16,.9)';
      pctx.fill();
      pctx.strokeStyle = 'rgba(80,120,110,.25)';
      pctx.stroke();
    };

    const drawOpenPit = (
      cx: number, cy: number, R: number,
      m: NonNullable<ReturnType<typeof useStore.getState>['track']>,
      P: typeof STYLES.normal, t: number,
      base: string, closed: boolean,
    ) => {
      ridgeLine(cx, cy, R, hash(m.id) % 10);
      const N = 9;
      const sq = 0.42;
      const dstep = R * 0.052;
      for (let k = 0; k < N; k++) {
        const rOut = R * (1 - (0.85 * k) / N);
        const rIn = R * (1 - (0.85 * (k + 1)) / N);
        const yc = cy + k * dstep;
        pctx.beginPath();
        pctx.ellipse(cx, yc, rOut, rOut * sq, 0, 0, TAU);
        pctx.ellipse(cx, yc, rIn, rIn * sq, 0, 0, TAU, true);
        pctx.fillStyle = k % 2 ? mix(base, '#000000', 0.18) : base;
        pctx.fill('evenodd');
        pctx.strokeStyle = 'rgba(255,255,255,.14)';
        pctx.lineWidth = 1;
        pctx.beginPath();
        pctx.ellipse(cx, yc, rOut, rOut * sq, 0, Math.PI, TAU);
        pctx.stroke();
      }
      pctx.beginPath();
      pctx.ellipse(cx, cy + (N - 1) * dstep, R * 0.15, R * 0.15 * sq, 0, 0, TAU);
      pctx.fillStyle = mix(base, '#000000', 0.5);
      pctx.fill();
      if (closed) {
        pctx.beginPath();
        pctx.ellipse(cx, cy + (N - 1) * dstep, R * 0.11, R * 0.09, 0, 0, TAU);
        pctx.fillStyle = 'rgba(60,110,140,.7)';
        pctx.fill();
      } else {
        pctx.fillStyle = '#0c0f12';
        pctx.fillRect(cx - R * 0.05, cy + (N - 1) * dstep, 7, 4);
        pctx.fillRect(cx + R * 0.07, cy + (N - 1) * dstep + 2, 7, 4);
      }
      const pts: [number, number][] = [];
      const steps = 140;
      const turns = 2.3;
      for (let i = 0; i <= steps; i++) {
        const p = i / steps;
        const r = R * (1.0 - p * 0.86);
        const th = -0.6 + p * turns * TAU;
        const dep = p * (N - 1) * dstep;
        pts.push([cx + r * Math.cos(th), cy + dep + r * Math.sin(th) * sq]);
      }
      pctx.beginPath();
      pts.forEach((pt, i) => (i ? pctx.lineTo(pt[0], pt[1]) : pctx.moveTo(pt[0], pt[1])));
      pctx.strokeStyle = closed ? 'rgba(120,110,100,.5)' : 'rgba(200,190,170,.65)';
      pctx.lineWidth = 3;
      pctx.stroke();
      if (!closed) {
        pctx.fillStyle = P.accent;
        for (let i = 0; i < 3; i++) {
          const ph = (t * 0.00006 + i / 3) % 1;
          const idx = Math.floor(ph * steps);
          const p = pts[idx];
          const q = pts[Math.min(idx + 1, steps)];
          const ang = Math.atan2(q[1] - p[1], q[0] - p[0]);
          pctx.save();
          pctx.translate(p[0], p[1]);
          pctx.rotate(ang);
          pctx.fillRect(-3, -2, 6, 4);
          pctx.restore();
        }
      }
      pctx.fillStyle = hexA(P.text, 0.55);
      pctx.font = '10px "IBM Plex Mono",monospace';
      const dep =
        m.id === 'bingham' ? 1200 :
        m.id === 'chuqui' ? 1050 :
        m.id === 'superpit' ? 700 :
        m.id === 'mirny' ? 575 : 500;
      for (let k = 0; k < N; k += 2) {
        pctx.fillText('-' + Math.round((dep * k) / (N - 1)) + ' m', cx + R * 1.02, cy + k * dstep + 3);
      }
      if (closed) {
        pctx.fillStyle = '#ff5f56';
        pctx.font = '11px "IBM Plex Mono",monospace';
        pctx.fillText('◆ CARE & MAINTENANCE — REHABILITATION REGIME', cx - R, cy - R * 0.8);
      }
    };

    const drawUnderground = (
      cx: number, cy: number, R: number,
      m: NonNullable<ReturnType<typeof useStore.getState>['track']>,
      P: typeof STYLES.normal, t: number,
    ) => {
      ridgeLine(cx, cy, R, hash(m.id) % 10);
      const ground = cy - R * 0.42;
      const depth = cy + R * 0.75;
      pctx.strokeStyle = P.text;
      pctx.lineWidth = 1.5;
      pctx.beginPath();
      pctx.moveTo(cx - R * 1.5, ground); pctx.lineTo(cx + R * 1.5, ground);
      pctx.stroke();
      pctx.strokeStyle = P.accent;
      pctx.lineWidth = 2;
      pctx.beginPath();
      pctx.moveTo(cx - 26, ground); pctx.lineTo(cx, ground - R * 0.22); pctx.lineTo(cx + 26, ground);
      pctx.moveTo(cx - 14, ground); pctx.lineTo(cx + 14, ground);
      pctx.stroke();
      pctx.beginPath();
      pctx.arc(cx, ground - R * 0.22, 7, 0, TAU);
      pctx.stroke();
      pctx.strokeStyle = P.text;
      pctx.lineWidth = 2;
      pctx.beginPath();
      pctx.moveTo(cx, ground); pctx.lineTo(cx, depth);
      pctx.stroke();
      const cyg = lerp(ground, depth, (Math.sin(t * 0.0012) + 1) / 2);
      pctx.fillStyle = P.accent;
      pctx.fillRect(cx - 5, cyg - 4, 10, 8);
      const maxD = m.id === 'mponeng' ? 4000 : 2400;
      const nLv = 6;
      pctx.font = '9px "IBM Plex Mono",monospace';
      for (let i = 1; i <= nLv; i++) {
        const y = lerp(ground, depth, i / nLv);
        const Lw = R * (0.45 + (((i * 7 + hash(m.id)) % 40) / 100));
        pctx.strokeStyle = P.text;
        pctx.lineWidth = 1.2;
        pctx.beginPath();
        pctx.moveTo(cx - Lw, y); pctx.lineTo(cx + Lw, y);
        pctx.stroke();
        const a = 0.15 + 0.3 * Math.abs(Math.sin(t * 0.001 + i));
        pctx.fillStyle = hexA(COMMS[(m as typeof m & {comms: never[]}).comms[0] as never]?.col ?? '#ffd76a', a);
        [-Lw * 0.6, -Lw * 0.2, Lw * 0.4].forEach((ox) => pctx.fillRect(cx + ox, y - 8, 14, 7));
        pctx.fillStyle = hexA(P.text, 0.5);
        pctx.fillText('-' + Math.round((maxD * i) / nLv) + ' m', cx - Lw - 52, y + 3);
        if (i % 2 === 0) {
          pctx.strokeStyle = hexA(P.text, 0.3);
          pctx.beginPath();
          pctx.moveTo(cx + Lw, y); pctx.lineTo(cx + Lw, ground);
          pctx.stroke();
        }
      }
      pctx.fillStyle = P.accent;
      pctx.fillRect(cx - 8, depth - 6, 16, 10);
      pctx.fillStyle = hexA(P.text, 0.7);
      pctx.font = '10px "IBM Plex Mono",monospace';
      pctx.fillText('SHAFT ▼ ' + m.name.toUpperCase() + (m.id === 'mponeng' ? ' — DEEPEST MINE ON EARTH' : ''), cx - R, ground - 14);
    };

    const drawBrinePonds = (
      cx: number, cy: number, R: number,
      m: NonNullable<ReturnType<typeof useStore.getState>['track']>,
      P: typeof STYLES.normal, t: number,
    ) => {
      ridgeLine(cx, cy, R, hash(m.id) % 10);
      const cols = 7;
      const rows = 4;
      const pw = R * 0.24;
      const ph = R * 0.1;
      const gap = 6;
      for (let r = 0; r < rows; r++)
        for (let c = 0; c < cols; c++) {
          const stage = (r + c) % 5;
          const x = cx - (cols * pw) / 2 + c * (pw + gap);
          const y = cy - (rows * (ph + gap)) / 2 + r * (ph + gap) + R * 0.25;
          const a = 0.75 + 0.2 * Math.sin(t * 0.0015 + c + r);
          pctx.fillStyle = hexA(POND_COLS[stage], P.style === 'noir' || P.style === 'whitehot' ? 0.4 : a);
          pctx.fillRect(x, y, pw, ph);
          pctx.strokeStyle = 'rgba(0,0,0,.4)';
          pctx.strokeRect(x, y, pw, ph);
          if (stage >= 3 && P.style !== 'noir') {
            pctx.fillStyle = 'rgba(255,255,255,.5)';
            pctx.beginPath();
            pctx.moveTo(x + pw * 0.2, y + ph);
            pctx.lineTo(x + pw * 0.5, y + ph * 0.3);
            pctx.lineTo(x + pw * 0.8, y + ph);
            pctx.closePath();
            pctx.fill();
          }
        }
      pctx.fillStyle = P.accent;
      pctx.fillRect(cx - (cols * pw) / 2 - 24, cy + R * 0.25, 10, 10);
      pctx.strokeStyle = P.accent;
      pctx.lineWidth = 2;
      pctx.setLineDash([4, 4]);
      pctx.beginPath();
      pctx.moveTo(cx - (cols * pw) / 2 - 14, cy + R * 0.25 + 5);
      pctx.lineTo(cx + (cols * (pw + gap)) / 2, cy + R * 0.25 + 5);
      pctx.stroke();
      pctx.setLineDash([]);
      pctx.fillStyle = hexA(P.text, 0.75);
      pctx.font = '10px "IBM Plex Mono",monospace';
      pctx.fillText('BRINE STAGING 1→5 · Li CONC RISES WITH STAGE', cx - R, cy - R * 0.5);
      pctx.fillText('SOLAR EVAPORATION — ' + m.name.toUpperCase(), cx - R, cy + R * 0.55);
    };

    const drawTSFPit = (
      cx: number, cy: number, R: number,
      m: NonNullable<ReturnType<typeof useStore.getState>['track']> & { haz: string },
      P: typeof STYLES.normal, t: number,
    ) => {
      ridgeLine(cx, cy, R, hash(m.id) % 10);
      const ground = cy - R * 0.3;
      const col = (HAZCOL as Record<string, string>)[m.haz] || '#5bd6dd';
      for (let i = 0; i < 4; i++) {
        const y = ground + i * R * 0.1;
        pctx.fillStyle = mix(i % 2 ? '#7a6a52' : '#5c5040', '#000000', 0.1);
        pctx.beginPath();
        pctx.moveTo(cx - R * 0.9 - i * R * 0.05, y);
        pctx.lineTo(cx - R * 0.55 - i * R * 0.03, y + R * 0.02);
        pctx.lineTo(cx - R * 0.55 - i * R * 0.03, y + R * 0.1);
        pctx.lineTo(cx - R * 0.9 - i * R * 0.05, y + R * 0.1);
        pctx.closePath();
        pctx.fill();
        pctx.beginPath();
        pctx.moveTo(cx + R * 0.9 + i * R * 0.05, y);
        pctx.lineTo(cx + R * 0.55 + i * R * 0.03, y + R * 0.02);
        pctx.lineTo(cx + R * 0.55 + i * R * 0.03, y + R * 0.1);
        pctx.lineTo(cx + R * 0.9 + i * R * 0.05, y + R * 0.1);
        pctx.closePath();
        pctx.fill();
      }
      const py = ground + R * 0.06;
      const fail = m.haz === 'FAILED';
      pctx.beginPath();
      pctx.ellipse(cx, py, R * 0.5, R * 0.14, 0, 0, TAU);
      pctx.fillStyle = fail ? 'rgba(90,70,40,.8)' : 'rgba(70,130,160,.6)';
      pctx.fill();
      if (!fail) {
        pctx.strokeStyle = hexA(col, 0.5);
        pctx.lineWidth = 1;
        pctx.beginPath();
        pctx.ellipse(cx, py, R * 0.5 * (1 - 0.06 * Math.sin(t * 0.001)), R * 0.14, 0, 0, TAU);
        pctx.stroke();
      }
      pctx.strokeStyle = col;
      pctx.lineWidth = 2;
      pctx.beginPath();
      pctx.moveTo(cx + R * 0.2, py); pctx.lineTo(cx + R * 0.2, py - R * 0.34);
      pctx.stroke();
      pctx.strokeRect(cx + R * 0.2 - 6, py - R * 0.4, 12, 12);
      const a = 0.4 + 0.4 * Math.sin(t * 0.004);
      pctx.fillStyle = hexA(col, a);
      pctx.beginPath();
      pctx.arc(cx - R * 0.35, py, 4, 0, TAU);
      pctx.fill();
      pctx.fillStyle = hexA(P.text, 0.8);
      pctx.font = '10px "IBM Plex Mono",monospace';
      pctx.fillText(
        (fail ? '◆ STATUS: FAILED — CASE FILE' : '▲ STATUS: ' + (m as { status: string }).status + ' · CONSEQUENCE ' + m.haz) + ' · ' + m.name.toUpperCase(),
        cx - R, ground - R * 0.15,
      );
      if (fail) {
        pctx.fillStyle = hexA('#ff5f56', 0.9);
        pctx.fillText('RELEASE FOOTPRINT — SEE WIRE ENTRY / PUBLIC INQUIRY', cx - R, py + R * 0.25);
      }
    };

    const drawSitePlan = (
      cx: number, cy: number, R: number,
      m: NonNullable<ReturnType<typeof useStore.getState>['track']>,
      P: typeof STYLES.normal, t: number,
    ) => {
      ridgeLine(cx, cy, R, hash(m.id) % 10);
      const gy = cy + R * 0.3;
      pctx.setLineDash([6, 5]);
      pctx.strokeStyle = P.cy || '#5bd6dd';
      pctx.lineWidth = 2;
      pctx.beginPath();
      pctx.ellipse(cx - R * 0.3, gy, R * 0.3, R * 0.12, 0, 0, TAU);
      pctx.stroke();
      pctx.setLineDash([]);
      pctx.fillStyle = hexA(P.cy || '#5bd6dd', 0.08);
      pctx.fill();
      pctx.fillStyle = '#141c22';
      pctx.strokeStyle = P.text;
      pctx.lineWidth = 1;
      ([[R * 0.25, -R * 0.22, 0.18, 0.08],
       [R * 0.25, -R * 0.06, 0.18, 0.06],
       [R * 0.55, -R * 0.16, 0.12, 0.1],
       [R * 0.4,  R * 0.1,  0.16, 0.06]] as [number, number, number, number][]).forEach((b) => {
        pctx.fillRect(cx + b[0], gy + b[1] - R * b[3], R * b[2], R * b[3]);
        pctx.strokeRect(cx + b[0], gy + b[1] - R * b[3], R * b[2], R * b[3]);
      });
      ([[cx + R * 0.28, gy - R * 0.28], [cx + R * 0.33, gy - R * 0.28]] as [number, number][]).forEach((pair) => {
        pctx.strokeStyle = P.text;
        pctx.beginPath();
        pctx.moveTo(pair[0], pair[1] + R * 0.1); pctx.lineTo(pair[0], pair[1] - R * 0.12);
        pctx.stroke();
        const a = 0.3 + 0.5 * Math.sin(t * 0.003 + pair[0]);
        pctx.fillStyle = hexA('#ff5f56', a);
        pctx.beginPath();
        pctx.arc(pair[0], pair[1] - R * 0.13, 3, 0, TAU);
        pctx.fill();
      });
      pctx.strokeStyle = 'rgba(200,190,170,.5)';
      pctx.lineWidth = 3;
      pctx.beginPath();
      pctx.moveTo(cx - R * 0.55, gy + R * 0.16);
      pctx.quadraticCurveTo(cx, gy + R * 0.3, cx + R * 0.75, gy + R * 0.05);
      pctx.stroke();
      for (let i = 0; i < 9; i++) {
        const a = 0.3 + 0.5 * Math.sin(t * 0.002 + i);
        const x = cx - R * 0.3 + (((hash(m.id) + i * 37) % 100) / 100) * R * 0.6 - R * 0.3;
        const y = gy - R * 0.12 + (((hash(m.id) + i * 53) % 60) / 100) * R * 0.12;
        pctx.fillStyle = hexA(P.accent, a);
        pctx.fillRect(x, y, 3, 3);
      }
      pctx.fillStyle = hexA(P.text, 0.8);
      pctx.font = '10px "IBM Plex Mono",monospace';
      const isPl = !!(m as { pl?: boolean }).pl;
      pctx.fillText((isPl ? 'PROCESSING SITE PLAN — ' : 'DEVELOPMENT SITE PLAN — ') + m.name.toUpperCase(), cx - R, gy - R * 0.35);
    };

    const drawPit = (t: number) => {
      const st = useStore.getState();
      const m = st.track;
      if (!m) { st.setMode('globe'); return; }
      const P = STYLES[st.style];
      const w = st.W, h = st.H;
      pctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
      const sky = pctx.createLinearGradient(0, 0, 0, h * 0.6);
      sky.addColorStop(0, P.bg);
      sky.addColorStop(
        1,
        st.style === 'ironbow' ? '#3a0c00' :
        (st.style === 'noir' || st.style === 'whitehot') ? '#1a1a1a' :
        (st.style === 'crt' || st.style === 'nvg') ? '#041a08' : '#08131c',
      );
      pctx.fillStyle = sky;
      pctx.fillRect(0, 0, w, h);
      pctx.fillStyle = P.star;
      STARS.slice(0, 120).forEach((s) => {
        pctx.globalAlpha = 0.5;
        pctx.fillRect(s[0] * w, s[1] * h * 0.5, 1.5, 1.5);
      });
      pctx.globalAlpha = 1;
      const cx = w / 2 + mouseRef.current[0] * 0.03;
      const cy = h * 0.46 + mouseRef.current[1] * 0.015;
      const R = Math.min(w, h) * 0.34;

      if (m.tsf) drawTSFPit(cx, cy, R, m as typeof m & { haz: string }, P, t);
      else if ((m as { pl?: boolean }).pl || m.status === 'D') drawSitePlan(cx, cy, R, m, P, t);
      else if (m.type === 'UG') drawUnderground(cx, cy, R, m, P, t);
      else if (m.type === 'BR') drawBrinePonds(cx, cy, R, m, P, t);
      else {
        const commCol = COMMS[m.comms[0]].col;
        const closed = m.status === 'C';
        const base = mix(commCol, closed ? '#5c5148' : '#6b4a2f', closed ? 0.75 : 0.55);
        drawOpenPit(cx, cy, R, m, P, t, base, closed);
      }

      const hz = pctx.createRadialGradient(cx, cy, R * 0.7, cx, cy, R * 2.1);
      hz.addColorStop(0, 'rgba(0,0,0,0)');
      hz.addColorStop(1, 'rgba(0,0,0,.5)');
      pctx.fillStyle = hz;
      pctx.fillRect(0, 0, w, h);

      // Title
      const titleEl = document.getElementById('pit-title');
      if (titleEl) {
        const kindLabel = m.tsf ? 'TAILINGS FACILITY' : (m as { pl?: boolean }).pl ? 'PROCESSING SITE' : COMMS[m.comms[0]].name.toUpperCase();
        titleEl.textContent = 'PIT VIEW — ' + m.name.toUpperCase() + ' · ' + kindLabel + ' · MODELED GEOMETRY';
      }
    };

    const frame = (t: number) => {
      rafRef.current = requestAnimationFrame(frame);
      const st = useStore.getState();
      if (st.mode !== 'pit') return;
      try {
        drawPit(t);
      } catch (err) {
        st.pushConsole('PIT FRAME ERROR: ' + (err instanceof Error ? err.message : String(err)), 'c-err');
      }
    };

    rafRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  const mode = useStore((s) => s.mode);

  return (
    <div
      id="pit"
      className={mode === 'pit' ? 'fixed inset-0 z-[300] block bg-[#010304]' : 'hidden'}
    >
      <canvas
        id="pitc"
        ref={canvasRef}
        className="absolute inset-0"
      />
      <div className="pit-top absolute top-0 left-0 right-0 flex items-center gap-3.5 px-3.5 py-2.5 z-[2]">
        <span id="pit-title" className="font-head text-[12px] tracking-[0.16em] text-[var(--acc)]" />
        <button
          id="pit-exit"
          className="ml-auto border border-[var(--brd2)] text-[var(--txt)] px-2.5 py-0.5 text-[11px] tracking-wider uppercase hover:border-[var(--acc)] hover:text-[var(--acc)]"
          onClick={() => useStore.getState().setMode('globe')}
        >
          ✕ EXIT
        </button>
      </div>
      <div className="pit-warn absolute bottom-3 left-0 right-0 text-center text-[9px] tracking-[0.18em] text-[var(--dim)] z-[2]">
        MODELED GEOMETRY · PUBLIC DATA · NOT FOR NAVIGATION
      </div>
    </div>
  );
}

'use client';

import { useState, useEffect, useRef } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { GLY, HAZCOL, kindOf, haversine } from '@/lib/motherlode/constants';
import { COMMS } from '@/lib/motherlode/data';
import TrackCard from './TrackCard';

export default function RightPanel() {
  const [tab, setTab] = useState<'contacts' | 'wire'>('contacts');
  const track = useStore((s) => s.track);
  const contactCount = useStore((s) => s.contactCount);
  const wire = useStore((s) => s.wire);

  // Pull roster DOM (rendered by Globe) into React for re-render when it changes
  const rosterRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const id = setInterval(() => {
      const el = document.getElementById('roster-sub');
      if (el && rosterRef.current) {
        // Trigger a re-render of roster header — actual roster list rendered by Globe into #roster
      }
    }, 250);
    return () => clearInterval(id);
  }, []);

  const rosterSub = track
    ? '≤ 500 KM OF ' + track.name.toUpperCase()
    : 'IN VIEW · ' + contactCount + ' CONTACTS';

  return (
    <aside
      id="right"
      className="panel fixed top-[58px] right-3 w-[292px] bg-[var(--panel)] border border-[var(--brd)] z-40 backdrop-blur-[5px] flex flex-col max-h-[calc(100vh-152px)]"
    >
      <div className="tabs flex border-b border-[var(--brd)] flex-none">
        <button
          onClick={() => setTab('contacts')}
          className={
            'tabbtn flex-1 border-none px-0 py-1.5 tracking-[0.18em] text-[10px] ' +
            (tab === 'contacts'
              ? 'text-[var(--acc)] bg-[rgba(255,180,84,0.06)] border-r border-[var(--brd)]'
              : 'text-[var(--dim)] border-r border-[var(--brd)]')
          }
        >
          CONTACTS
        </button>
        <button
          onClick={() => setTab('wire')}
          className={
            'tabbtn flex-1 border-none px-0 py-1.5 tracking-[0.18em] text-[10px] ' +
            (tab === 'wire' ? 'text-[var(--acc)] bg-[rgba(255,180,84,0.06)]' : 'text-[var(--dim)]')
          }
        >
          WIRE
        </button>
      </div>

      {tab === 'contacts' && (
        <div id="tab-contacts" className="pc overflow-y-auto px-3 py-2 flex-1 min-h-0">
          <div id="roster-sub" className="text-[9px] text-[var(--dim)] tracking-[0.12em] my-0.5 mb-1.5">
            {rosterSub}
          </div>
          {/* Globe renders roster list into this element via direct DOM for perf */}
          <div id="roster" ref={rosterRef} className="text-[var(--txt)]" />
        </div>
      )}

      {tab === 'wire' && (
        <div id="tab-wire" className="pc overflow-y-auto px-3 py-2 flex-1 min-h-0">
          <div className="text-[9px] text-[var(--dim)] tracking-[0.12em] my-0.5 mb-1.5">
            INCIDENT &amp; WIRE FEED · SIMULATED
          </div>
          <div id="wire" className="text-[var(--txt)]">
            {wire.map((w, i) => (
              <div
                key={i}
                className={
                  'wi flex gap-2 py-1.5 px-1 border-b border-[rgba(24,50,66,0.5)] cursor-pointer text-[10.5px] leading-[1.45] hover:bg-[rgba(91,214,221,0.06)] ' +
                  (w.sev === 'info' ? 'border-l-2 border-l-[var(--cy)]' :
                   w.sev === 'warn' ? 'border-l-2 border-l-[var(--acc)]' :
                   'border-l-2 border-l-[var(--red)]')
                }
                onClick={() => {
                  if (w.ref) {
                    useStore.getState().trackSite(w.ref);
                    setTab('contacts');
                  }
                }}
              >
                <span className="wt text-[var(--dim)] flex-none text-[9px] pt-0.5">{w.time}</span>
                <div
                  className="wtxt"
                  style={{ color: w.sev === 'alert' ? 'var(--red)' : 'inherit' }}
                  dangerouslySetInnerHTML={{ __html: w.text }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      <TrackCard />
    </aside>
  );
}

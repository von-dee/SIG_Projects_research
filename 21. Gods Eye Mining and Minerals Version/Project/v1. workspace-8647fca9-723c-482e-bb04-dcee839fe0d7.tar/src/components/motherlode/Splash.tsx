'use client';

import { useEffect, useRef, useState } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { BOOT_LINES, MISSIONS } from '@/lib/motherlode/constants';
import { COMMS } from '@/lib/motherlode/data';
import { SITES } from '@/lib/motherlode/sites';
import { applyHash } from '@/lib/motherlode/commands';

export default function Splash() {
  const bootStage = useStore((s) => s.bootStage);
  const setBootStage = useStore((s) => s.setBootStage);
  const bootChars = useStore((s) => s.bootChars);
  const setBootChars = useStore((s) => s.setBootChars);
  const [typed, setTyped] = useState('');
  const [done, setDone] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Boot typewriter
  useEffect(() => {
    if (bootStage !== 'typing') return;
    let li = 0, ci = 0;

    const render = (cur: string) => {
      const html = BOOT_LINES.slice(0, li).map((l) => `<span class="${l[1]}">${l[0]}</span>`).join('\n') +
        (li < BOOT_LINES.length ? '\n<span class="' + BOOT_LINES[li][1] + '">' + cur + '</span>' : '');
      setTyped(html);
    };

    const tick = () => {
      if (bootStage !== 'typing') return;
      if (li >= BOOT_LINES.length) {
        setBootStage('missions');
        return;
      }
      const line = BOOT_LINES[li][0];
      ci++;
      render(line.slice(0, ci));
      if (ci >= line.length) {
        li++;
        ci = 0;
        timerRef.current = setTimeout(tick, 140);
      } else {
        timerRef.current = setTimeout(tick, 9);
      }
    };

    tick();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [bootStage]);

  // On 'missions' stage, set up the missions UI
  // On done, hide splash
  useEffect(() => {
    if (bootStage !== 'done') return;
    const id = setTimeout(() => setDone(true), 100);
    return () => clearTimeout(id);
  }, [bootStage]);

  // On mount, attempt hash restoration
  useEffect(() => {
    const fromHash = applyHash();
    if (fromHash) {
      setBootStage('done');
    }
  }, [setBootStage]);

  if (done) return null;

  const launch = (i: number) => {
    const s = useStore.getState();
    const mission = MISSIONS[i];
    const keys = Object.keys(s.comm) as (keyof typeof s.comm)[];
    if (i === 0) {
      // LIGHT UP THE BELT — copper
      keys.forEach((k) => (s.comm[k] = false));
      s.comm.CU = true;
      s.plant = true;
      const t = SITES.find((x) => x.id === 'escondida');
      if (t) s.trackSite(t);
    } else if (i === 1) {
      // BATTERY CHAIN
      keys.forEach((k) => (s.comm[k] = false));
      (['LI','NI','CO','REE'] as (keyof typeof s.comm)[]).forEach((k) => (s.comm[k] = true));
      const t = SITES.find((x) => x.id === 'atacama');
      if (t) s.trackSite(t);
    } else if (i === 2) {
      // HAZARD WATCH
      keys.forEach((k) => (s.comm[k] = false));
      s.tsf = true;
      const t = SITES.find((x) => x.id === 'feijao');
      if (t) s.trackSite(t);
    } else if (i === 3) {
      // IRON GIANTS
      keys.forEach((k) => (s.comm[k] = false));
      s.comm.FE = true;
      const t = SITES.find((x) => x.id === 'carajas');
      if (t) s.trackSite(t);
    } else {
      // EXPLORE MANUALLY
      keys.forEach((k) => (s.comm[k] = true));
      s.tsf = true;
    }
    s.setBootStage('done');
  };

  const skip = () => {
    const s = useStore.getState();
    if (s.bootStage === 'typing') {
      setBootStage('missions');
    } else {
      setBootStage('done');
    }
  };

  return (
    <div
      id="splash"
      className="fixed inset-0 z-[500] bg-[#020507] flex items-center justify-center"
      style={{ display: done ? 'none' : 'flex' }}
    >
      <div className="box w-[min(860px,92vw)]">
        <div className="brandline font-head text-[30px] tracking-[0.3em] text-white mb-1">MOTHERLODE</div>
        <div className="tagline text-[var(--dim)] text-[11px] tracking-[0.16em] mb-[22px]">
          A mineral reconnaissance satellite in your browser. The deposits are real, the data is public.
        </div>
        <pre
          id="bootlog"
          className="text-[12px] leading-[1.75] text-[#8dffa8] min-h-[280px] whitespace-pre-wrap tracking-[0.03em] font-mono"
          dangerouslySetInnerHTML={{ __html: typed }}
        />
        {bootStage === 'missions' && (
          <div
            id="missions"
            className="grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] gap-2.5 mt-[26px]"
          >
            {MISSIONS.map((m, i) => (
              <div
                key={m.t}
                onClick={() => launch(i)}
                className="mi border border-[var(--brd)] bg-[rgba(8,16,22,0.8)] p-3 cursor-pointer flex flex-col gap-2 hover:border-[var(--acc)]"
              >
                <div className="mt font-head text-[12px] tracking-[0.14em] text-[var(--acc)]">{m.t}</div>
                <div className="md text-[10px] text-[var(--dim)] leading-[1.55] flex-1">{m.d}</div>
                <div className="go text-[9px] tracking-[0.2em] text-[var(--grn)]">▸ LAUNCH MISSION</div>
              </div>
            ))}
          </div>
        )}
      </div>
      <button
        id="btn-skip"
        onClick={skip}
        className="absolute top-4 right-4 border border-[var(--brd2)] text-[var(--txt)] px-2.5 py-1 text-[11px] tracking-wider uppercase hover:border-[var(--acc)] hover:text-[var(--acc)]"
      >
        {bootStage === 'typing' ? 'SKIP ▸' : 'ENTER NOW ▸'}
      </button>
    </div>
  );
}

'use client';

import { useStore } from '@/lib/motherlode/store';
import { STYLES, STYLE_KEYS, TSTYLE, CSS_VARS } from '@/lib/motherlode/styles';
import type { StyleKey } from '@/lib/motherlode/types';

export default function StyleBar() {
  const style = useStore((s) => s.style);
  const setStyle = useStore((s) => s.setStyle);

  return (
    <>
      <StyleInjector styleKey={style} />
      <div
        id="stylebar"
        className="fixed left-1/2 -translate-x-1/2 bottom-[46px] flex gap-1.5 z-[45]"
      >
        {STYLE_KEYS.map((k, i) => (
          <button
            key={k}
            onClick={() => setStyle(k)}
            className={
              'text-[9px] px-2.5 py-1 bg-[var(--panel)] border ' +
              (k === style
                ? 'border-[var(--acc)] text-[var(--acc)] shadow-[0_0_12px_rgba(255,180,84,0.25)]'
                : 'border-[var(--brd2)] text-[var(--dim)] hover:border-[var(--acc)] hover:text-[var(--acc)]')
            }
          >
            {i + 1} {TSTYLE[k]}
          </button>
        ))}
      </div>
    </>
  );
}

// Inject CSS variables onto body when style changes
function StyleInjector({ styleKey }: { styleKey: StyleKey }) {
  useEffect_css(styleKey);
  return null;
}

import { useEffect } from 'react';
function useEffect_css(styleKey: StyleKey) {
  useEffect(() => {
    const vars = CSS_VARS[styleKey];
    const body = document.body;
    Object.entries(vars).forEach(([k, v]) => {
      body.style.setProperty(k, v);
    });
    body.dataset.style = styleKey;
  }, [styleKey]);
}

// expose STYLES name via export
export { STYLES };

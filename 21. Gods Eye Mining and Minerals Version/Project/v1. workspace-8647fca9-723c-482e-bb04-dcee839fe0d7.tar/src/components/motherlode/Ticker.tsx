'use client';

import { useEffect, useState } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { fmtN } from '@/lib/motherlode/constants';

export default function Ticker() {
  const prices = useStore((s) => s.prices);
  const stepPrices = useStore((s) => s.stepPrices);
  const [flashKey, setFlashKey] = useState<string | null>(null);

  // Random walk every 2.6s
  useEffect(() => {
    const id = setInterval(() => {
      stepPrices();
      setFlashKey(prices[Math.floor(Math.random() * prices.length)].k);
    }, 2600);
    return () => clearInterval(id);
  }, [prices, stepPrices]);

  const items = prices.map((p) => {
    const chg = ((p.val - p.prev) / p.prev) * 100;
    const flashing = flashKey === p.k;
    return (
      <span
        key={p.k}
        className="titem text-[11px] tracking-[0.05em]"
        style={flashing ? { color: chg >= 0 ? 'var(--grn)' : 'var(--red)' } : undefined}
      >
        <b className="text-[var(--acc)] font-semibold">{p.k}</b>{' '}
        <span className="tk-val">{fmtN(p.val.toFixed(p.val > 500 ? 0 : 2))}</span>{' '}
        <i className={chg >= 0 ? 'up text-[var(--grn)]' : 'down text-[var(--red)]'} style={{ fontStyle: 'normal', fontSize: '9.5px', marginLeft: '5px' }}>
          {(chg >= 0 ? '+' : '') + chg.toFixed(2)}%
        </i>{' '}
        <span className="c-dim text-[var(--dim)] text-[9px]">{p.u}</span>
      </span>
    );
  });

  const tags = (
    <>
      <span className="ttag text-[var(--dim)] text-[9px] tracking-[0.2em]">MOTHERLODE — NO DEPOSIT LEFT BEHIND</span>
      <span className="ttag text-[var(--dim)] text-[9px] tracking-[0.2em]">◈ KEYLESS · 100% LOCAL</span>
      <span className="ttag text-[var(--dim)] text-[9px] tracking-[0.2em]">◈ POSITIONS PUBLIC &amp; APPROX · PRICES SIMULATED · NOT INVESTMENT ADVICE</span>
    </>
  );

  // Duplicate items for seamless marquee
  const track = (
    <div className="ttrack inline-flex gap-[34px] whitespace-nowrap items-center pr-[34px]">
      {items}
      {tags}
    </div>
  );

  return (
    <div
      id="ticker"
      className="fixed left-0 right-0 bottom-0 h-[34px] bg-[rgba(3,7,10,0.97)] border-t border-[var(--brd)] flex items-center overflow-hidden z-[50]"
    >
      <div
        id="tk-inner"
        className="flex w-max animate-[tk_70s_linear_infinite] hover:[animation-play-state:paused]"
        style={{ animation: 'tk 70s linear infinite' }}
      >
        {track}
        {track}
      </div>
      <style jsx>{`
        @keyframes tk {
          to { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}

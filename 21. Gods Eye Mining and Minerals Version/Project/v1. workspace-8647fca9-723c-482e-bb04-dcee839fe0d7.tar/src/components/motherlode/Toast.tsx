'use client';

import { useStore } from '@/lib/motherlode/store';

export default function Toast() {
  const toast = useStore((s) => s.toast);
  if (!toast) return null;
  return (
    <div
      id="toast"
      className="fixed bottom-[92px] left-1/2 -translate-x-1/2 z-[480] bg-[var(--panel)] border border-[var(--acc)] text-[var(--acc)] px-4.5 py-1.5 text-[11px] tracking-[0.12em] whitespace-nowrap pointer-events-none"
      style={{ opacity: 1, transition: 'opacity .25s' }}
    >
      {toast}
    </div>
  );
}

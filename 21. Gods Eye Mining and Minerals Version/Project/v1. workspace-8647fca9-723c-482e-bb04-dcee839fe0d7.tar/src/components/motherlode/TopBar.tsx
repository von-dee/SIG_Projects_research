'use client';

import { useEffect, useState } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { runCommand } from '@/lib/motherlode/commands';

export default function TopBar() {
  const style = useStore((s) => s.style);
  const track = useStore((s) => s.track);
  const [clock, setClock] = useState('--:--:--');
  const [hudline, setHudline] = useState('');
  const [hudcenter, setHudcenter] = useState('');
  const fps = useStore((s) => s.fps);

  useEffect(() => {
    const id = setInterval(() => {
      const d = new Date();
      setClock(d.toISOString().slice(11, 19) + ' UTC');
    }, 250);
    return () => clearInterval(id);
  }, []);

  // Pull DOM-written HUD strings (set by Globe canvas) every 250ms
  useEffect(() => {
    const id = setInterval(() => {
      const hl = document.getElementById('hudline');
      if (hl) setHudline(hl.innerHTML);
      const hc = document.getElementById('hudcenter');
      if (hc) setHudcenter(hc.innerHTML);
    }, 200);
    return () => clearInterval(id);
  }, []);

  const togglePanels = (which: 'l' | 'r') => {
    const el = document.getElementById(which === 'l' ? 'left' : 'right');
    el?.classList.toggle('open');
  };

  return (
    <>
      <header
        id="top"
        className="fixed top-0 left-0 right-0 h-[46px] flex items-center gap-4 px-3.5 bg-gradient-to-b from-[rgba(4,9,12,0.97)] to-[rgba(4,9,12,0.85)] border-b border-[var(--brd)] z-[60]"
      >
        <div className="brand flex items-center gap-2.5 font-head font-bold tracking-[0.22em] text-[15px] text-white whitespace-nowrap">
          <span className="pulse w-2 h-2 rounded-full bg-[var(--grn)] shadow-[0_0_10px_var(--grn)] animate-pulse" />
          MOTHERLODE
          <span className="sub font-medium text-[9px] tracking-[0.3em] text-[var(--dim)] ml-0.5">
            MINERAL SURVEY CONSOLE
          </span>
        </div>
        <div
          id="hudline"
          className="ml-auto text-[10px] text-[var(--dim)] tracking-[0.08em] whitespace-nowrap overflow-hidden text-ellipsis"
          dangerouslySetInnerHTML={{ __html: hudline || `MRDS 91 <b>✓</b> · GTP 11 <b>✓</b> · PLANTS 7 <b>✓</b> · WIRE <b>SIM</b> · ${Math.floor(fps)} FPS` }}
        />
        <span id="clock" className="text-[11px] text-[var(--txt)] tracking-[0.1em] whitespace-nowrap">
          {clock}
        </span>
        <span className="chip on text-[9px] tracking-[0.14em] border border-[var(--brd2)] text-[var(--grn)] px-1.5 py-0.5 whitespace-nowrap">
          KEYLESS · LOCAL
        </span>
        <div className="btns flex gap-1.5">
          <button
            title="Layers"
            onClick={() => togglePanels('l')}
            className="border border-[var(--brd2)] text-[var(--txt)] px-2.5 py-0.5 text-[11px] tracking-wider uppercase hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            ▤
          </button>
          <button
            title="Contacts"
            onClick={() => togglePanels('r')}
            className="border border-[var(--brd2)] text-[var(--txt)] px-2.5 py-0.5 text-[11px] tracking-wider uppercase hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            ▥
          </button>
          <button
            id="btn-power"
            onClick={() => window.dispatchEvent(new Event('open-help'))}
            className="acc border border-[var(--acc)] text-[var(--acc)] px-2.5 py-0.5 text-[11px] tracking-wider uppercase hover:bg-[rgba(255,180,84,0.06)]"
          >
            POWER UP
          </button>
          <button
            onClick={() => runCommand('share')}
            className="border border-[var(--brd2)] text-[var(--txt)] px-2.5 py-0.5 text-[11px] tracking-wider uppercase hover:border-[var(--acc)] hover:text-[var(--acc)]"
          >
            SHARE
          </button>
        </div>
      </header>

      {track && (
        <div
          id="hudcenter"
          className="fixed top-[54px] left-1/2 -translate-x-1/2 z-30 text-[10px] tracking-[0.14em] text-[var(--dim)] bg-[rgba(0,0,0,0.4)] border border-[var(--brd)] px-3.5 py-0.5 whitespace-nowrap"
          dangerouslySetInnerHTML={{ __html: hudcenter || 'VIEW <b>—</b> · ALT <b>—</b> · CONTACTS <b>—</b>' }}
        />
      )}
    </>
  );
}

'use client';

import { useStore } from '@/lib/motherlode/store';

export default function TourBar() {
  const tour = useStore((s) => s.tour);
  if (!tour) return null;
  const step = tour.steps[tour.i];
  if (!step) return null;
  return (
    <div
      id="tourbar"
      className="fixed top-[86px] left-1/2 -translate-x-1/2 z-[80] max-w-[640px] bg-[var(--panel)] border border-[var(--brd)] px-4 py-1.5 text-[11px] tracking-[0.06em]"
    >
      <div className="tt text-[9px] tracking-[0.24em] text-[var(--acc)] mb-0.5">
        DISTRICT TOUR · {tour.name.toUpperCase()} · ESC TO EXIT
      </div>
      <div className="text-[var(--txt)]">
        {tour.i + 1}/{tour.steps.length} — {step.site.name.toUpperCase()} · {step.site.cc} — {step.site.note || ''}
      </div>
    </div>
  );
}

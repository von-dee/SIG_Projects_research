'use client';

import { useEffect, useState } from 'react';
import { useStore } from '@/lib/motherlode/store';
import { COMMS } from '@/lib/motherlode/data';
import { GLY, METHOD, HAZCOL, kindOf, fmtN } from '@/lib/motherlode/constants';
import type { Site } from '@/lib/motherlode/types';
import { SITES } from '@/lib/motherlode/sites';
import { haversine } from '@/lib/motherlode/constants';

export default function TrackCard() {
  const track = useStore((s) => s.track);
  const ore = useStore((s) => s.ore);
  const energy = useStore((s) => s.energy);
  const fleet = useStore((s) => s.fleet);
  const trackSite = useStore((s) => s.trackSite);
  const toggleLayer = useStore((s) => s.toggleLayer);
  const tsf = useStore((s) => s.tsf);
  const plant = useStore((s) => s.plant);

  // Tick telemetry each second while a track is active
  useEffect(() => {
    if (!track) return;
    const id = setInterval(() => useStore.getState().tickTelemetry(), 1000);
    return () => clearInterval(id);
  }, [track]);

  if (!track) return null;

  const s: Site = track;
  const st = useStore.getState();
  const st2 = (s.status === 'C' || (s.tsf && s.haz === 'FAILED'))
    ? 'C'
    : s.status === 'D' ? 'D' : 'A';
  const stLabel = s.tsf
    ? (s.haz === 'FAILED' ? 'FAILED' : s.status)
    : s.status;
  const chips = !s.tsf && !s.pl && s.comms.length
    ? s.comms.map((c) => (
        <span
          key={c}
          className="cc text-[9px] tracking-[0.1em] border px-1.5 py-0.5"
          style={{ color: COMMS[c].col, borderColor: COMMS[c].col }}
        >
          {COMMS[c].name}
        </span>
      ))
    : s.tsf ? (
      <span
        className="cc text-[9px] tracking-[0.1em] border px-1.5 py-0.5"
        style={{ color: HAZCOL[s.haz], borderColor: HAZCOL[s.haz] }}
      >
        {s.haz} CONSEQUENCE
      </span>
    ) : (
      <span
        className="cc text-[9px] tracking-[0.1em] border px-1.5 py-0.5"
        style={{ color: '#5bd6dd', borderColor: '#5bd6dd' }}
      >
        {s.out}
      </span>
    );

  return (
    <div
      id="trackcard"
      className="block border-t border-[var(--brd)] flex-none max-h-[46%] overflow-y-auto bg-[rgba(10,20,26,0.6)]"
    >
      <div className="flex items-center gap-2 px-3 py-2 border-b border-[var(--brd)]">
        <span id="tk-name" className="font-head text-[13px] tracking-[0.1em] text-white flex-1">
          {s.name}
        </span>
        <span
          id="tk-status"
          className={'text-[9px] tracking-[0.14em] px-1.5 py-0.5 border ' + (
            st2 === 'A' ? 'text-[var(--grn)] border-[var(--grn)]' :
            st2 === 'D' ? 'text-[var(--cy)] border-[var(--cy)]' :
            'text-[var(--dim)] border-[var(--dim)]'
          )}
        >
          {stLabel}
        </span>
      </div>

      <div className="tk-meta px-3 py-1.5 text-[10.5px]">
        <div className="r flex gap-2 py-0.5">
          <span className="k w-[84px] text-[var(--dim)] flex-none tracking-[0.08em]">SITE ID</span>
          <span className="v flex-1 text-[var(--txt)]">{s.code} · {GLY[kindOf(s)]} {METHOD[kindOf(s)]}</span>
        </div>
        <div className="r flex gap-2 py-0.5">
          <span className="k w-[84px] text-[var(--dim)] flex-none tracking-[0.08em]">COUNTRY</span>
          <span className="v flex-1 text-[var(--txt)]">{s.cc}</span>
        </div>
        <div className="r flex gap-2 py-0.5">
          <span className="k w-[84px] text-[var(--dim)] flex-none tracking-[0.08em]">OPERATOR</span>
          <span className="v flex-1 text-[var(--txt)]">{s.op}</span>
        </div>
        <div className="chips flex gap-1.5 flex-wrap my-1">{chips}</div>
        <div className="r flex gap-2 py-0.5">
          <span className="k w-[84px] text-[var(--dim)] flex-none tracking-[0.08em]">
            {s.tsf ? 'CAPACITY' : 'PRODUCTION'}
          </span>
          <span className="v flex-1 text-[var(--txt)]">{s.prod}</span>
        </div>
        <div className="r flex gap-2 py-0.5">
          <span className="k w-[84px] text-[var(--dim)] flex-none tracking-[0.08em]">
            {s.tsf ? 'STATUS' : 'ASSAY'}
          </span>
          <span className="v flex-1 text-[var(--txt)]">
            {s.tsf ? `${s.status} · ${s.haz}` : s.grade}
          </span>
        </div>
      </div>

      <div id="tk-note" className="px-3 pb-2 text-[9.5px] text-[var(--dim)] leading-[1.55]">
        {s.note || ''}
      </div>

      <div className="flex gap-3.5 px-3 py-1.5 border-t border-b border-[var(--brd)] text-[9px] text-[var(--dim)] tracking-[0.08em]">
        <span>ORE TODAY<b className="block text-[11px] text-[var(--acc)] tracking-[0.04em]">{fmtN(ore)} t</b></span>
        <span>ENERGY<b className="block text-[11px] text-[var(--acc)] tracking-[0.04em]">{energy.toFixed(1)} MWh</b></span>
        <span>FLEET<b className="block text-[11px] text-[var(--acc)] tracking-[0.04em]">{fleet} ACTIVE</b></span>
        <span className="ml-auto text-[var(--dim)]">LIVE TELEMETRY · SIM</span>
      </div>

      <div id="tk-btns" className="flex gap-1.5 px-3 py-2">
        <button
          onClick={() => {
            if (!useStore.getState().track) {
              useStore.getState().showToast('TRACK A SITE FIRST');
              return;
            }
            useStore.getState().setMode('pit');
          }}
          className="acc flex-1 text-[9px] py-1.5 border border-[var(--acc)] text-[var(--acc)] tracking-wider hover:bg-[rgba(255,180,84,0.06)]"
        >
          PIT MODE
        </button>
        <button
          onClick={() => {
            if (!tsf) toggleLayer('tsf');
            nearestOf((s) => !!s.tsf, s);
          }}
          className="flex-1 text-[9px] py-1.5 border border-[var(--brd2)] text-[var(--txt)] tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
        >
          NEAREST TSF
        </button>
        <button
          onClick={() => {
            if (!plant) toggleLayer('plant');
            nearestOf((s) => !!s.pl, s);
          }}
          className="flex-1 text-[9px] py-1.5 border border-[var(--brd2)] text-[var(--txt)] tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
        >
          NEAREST PLANT
        </button>
        <button
          onClick={() => trackSite(null)}
          className="flex-none w-[30px] text-[9px] py-1.5 border border-[var(--brd2)] text-[var(--txt)] tracking-wider hover:border-[var(--acc)] hover:text-[var(--acc)]"
        >
          ✕
        </button>
      </div>
    </div>
  );
}

function nearestOf(pred: (s: Site) => boolean, from: Site) {
  const st = useStore.getState();
  let best: Site | null = null;
  let bd = 1e9;
  SITES.forEach((s) => {
    if (pred(s) && s !== from) {
      const d = haversine(s, from);
      if (d < bd) { bd = d; best = s; }
    }
  });
  if (!best) {
    st.showToast('NONE IN DATASET');
    return;
  }
  st.showToast('NEAREST ▸ ' + best.name.toUpperCase() + ' · ' + Math.round(bd) + ' KM');
  st.trackSite(best);
}

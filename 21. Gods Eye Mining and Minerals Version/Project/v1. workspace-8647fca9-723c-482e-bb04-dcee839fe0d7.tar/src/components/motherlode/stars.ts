// Pre-generated star field for the globe background
export const STARS: [number, number, number][] = Array.from(
  { length: 230 },
  () => [Math.random(), Math.random(), Math.random() * 6],
);

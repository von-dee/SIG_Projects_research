// MOTHERLODE — Local console command parser

'use client';

import type { MotherlodeState } from './store';
import { useStore, siteOn, markerColor } from './store';
import { COMMS, MINES, PRICES, REGIONS } from './data';
import { SITES } from './sites';
import { STYLES, STYLE_KEYS, TSTYLE } from './styles';
import { TOURS } from './constants';
import { GLY, METHOD, HAZCOL, kindOf, haversine, fmtN, clamp, D2R, normAng } from './constants';
import { flyTo } from './geometry';
import type { Site, StyleKey, Comm } from './types';

function norm(q: string) {
  return q.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').replace(/\s+/g, ' ').trim();
}

function findSites(q: string): Site[] {
  q = norm(q);
  if (!q) return [];
  let r = SITES.filter((s) => s.id === q.replace(/\s+/g, '-') || norm(s.name) === q);
  if (!r.length) r = SITES.filter((s) => norm(s.name).startsWith(q));
  if (!r.length) r = SITES.filter((s) => norm(s.name).includes(q) || norm(s.cc).includes(q));
  return r.slice(0, 6);
}

const STYLE_WORDS: Record<string, StyleKey> = {
  nvg: 'nvg',
  'night vision': 'nvg',
  crt: 'crt',
  flir: 'ironbow',
  ironbow: 'ironbow',
  iron: 'ironbow',
  thermal: 'ironbow',
  white: 'whitehot',
  'white hot': 'whitehot',
  'white-hot': 'whitehot',
  noir: 'noir',
  spectral: 'spectral',
  normal: 'normal',
  tactical: 'normal',
};

function commFromWord(w: string): Comm | null {
  w = norm(w);
  const words: Record<string, Comm> = {
    copper: 'CU', cu: 'CU',
    gold: 'AU', au: 'AU',
    iron: 'FE', fe: 'FE',
    lithium: 'LI', li: 'LI',
    nickel: 'NI', ni: 'NI',
    cobalt: 'CO', co: 'CO',
    'rare earths': 'REE', 'rare earth': 'REE', ree: 'REE',
    uranium: 'U', coal: 'C',
    zinc: 'ZN', lead: 'ZN',
    silver: 'AG', pgm: 'PG', platinum: 'PG',
    bauxite: 'BX', potash: 'K', phosphate: 'P',
    molybdenum: 'MO', tin: 'SN',
    diamond: 'DIA', diamonds: 'DIA',
  };
  if (words[w]) return words[w];
  for (const k in words) {
    if (w.length > 2 && k.startsWith(w)) return words[k];
  }
  return null;
}

export function runCommand(raw: string) {
  const s = useStore.getState();
  const log = (html: string, cls = 'c-txt') => s.pushConsole(html, cls);
  const fly = (lat: number, lng: number, zoom: number, dur?: number) => flyTo(s.cam, lat, lng, zoom, dur);

  let q = norm(raw);
  q = q.replace(/^(take me|fly|go|goto|show me|turn on|switch to)\s+/, '').replace(/^to\s+/, '');
  const words = q.split(' ');
  const w0 = words[0];

  // Style by word
  for (const k in STYLE_WORDS) {
    if (q === k || q === k + ' mode') {
      s.setStyle(STYLE_WORDS[k]);
      log('Sensor stack ▸ ' + STYLES[STYLE_WORDS[k]].name, 'c-ok');
      return;
    }
  }
  if (/^[1-7]$/.test(q)) {
    const k = STYLE_KEYS[+q - 1];
    s.setStyle(k);
    log('Sensor stack ▸ ' + STYLES[k].name, 'c-ok');
    return;
  }
  if (/zoom out|globe view|reset|home|come home/.test(q)) {
    resetGlobe(s);
    log('Camera reset — full Earth.', 'c-ok');
    return;
  }
  if (['help', '?', 'commands'].includes(q)) {
    helpText(log);
    return;
  }
  if (['clear', 'cls'].includes(q)) {
    s.clearConsole();
    return;
  }
  if (w0 === 'fly' || w0 === 'track' || w0 === 'lock' || raw.toLowerCase().startsWith('take me')) {
    const rest = q.replace(/^(fly|track|lock|to)\s*/, '').trim();
    if (!rest) {
      log('Track what? Try: track grasberg', 'c-warn');
      return;
    }
    const r = findSites(rest);
    if (r.length === 1) {
      s.trackSite(r[0]);
      log('TRACKING ▸ ' + r[0].name.toUpperCase() + ' [' + r[0].code + '] — camera locked, telemetry card up.', 'c-ok');
      return;
    }
    if (r.length > 1) {
      listMatches(r, log);
      return;
    }
    const reg = REGIONS.find((x) => norm(x.label).includes(rest) || x.id === rest.replace(/\s+/g, '-'));
    if (reg) {
      fly(reg.lat, reg.lng, reg.zoom);
      log('FLYING ▸ ' + reg.label.toUpperCase(), 'c-ok');
      return;
    }
    log('No contact or region matched "' + rest + '".', 'c-err');
    return;
  }
  if (w0 === 'untrack' || q === 'clear track') {
    s.trackSite(null);
    log('Track cleared.', 'c-ok');
    return;
  }
  if (w0 === 'show' || w0 === 'hide' || w0 === 'enable' || w0 === 'disable') {
    const on = w0 === 'show' || w0 === 'enable';
    const rest = q.replace(/^(show|hide|enable|disable)\s*/, '').trim();
    if (rest === 'all') {
      s.setCommAll(on);
      s.toggleLayer('tsf'); if (!on && s.tsf) s.toggleLayer('tsf'); if (on && !s.tsf) s.toggleLayer('tsf');
      s.toggleLayer('plant'); if (!on && s.plant) s.toggleLayer('plant'); if (on && !s.plant) s.toggleLayer('plant');
      log(on ? 'ALL LAYERS ON' : 'ALL LAYERS OFF', 'c-ok');
      return;
    }
    const c = commFromWord(rest);
    if (c) {
      if (s.comm[c] !== on) s.toggleComm(c);
      log(COMMS[c].name.toUpperCase() + ' ' + (on ? 'ON' : 'OFF') + ' — ' + MINES.filter((x) => x.comms.includes(c)).length + ' sites.', 'c-ok');
      return;
    }
    if (/tsf|tailings/.test(rest)) {
      if (s.tsf !== on) s.toggleLayer('tsf');
      log('TAILINGS FACILITIES ' + (on ? 'ON' : 'OFF') + ' — ' + MINES.length + ' records.', 'c-ok');
      return;
    }
    if (/plant|smelter|processing/.test(rest)) {
      if (s.plant !== on) s.toggleLayer('plant');
      log('PROCESSING SITES ' + (on ? 'ON' : 'OFF'), 'c-ok');
      return;
    }
    log('Unknown layer "' + rest + '".', 'c-err');
    return;
  }
  if (w0 === 'style' || w0 === 'sensor') {
    const rest = words.slice(1).join(' ');
    if (STYLES[rest as StyleKey]) {
      s.setStyle(rest as StyleKey);
      log('Sensor stack ▸ ' + STYLES[rest as StyleKey].name, 'c-ok');
      return;
    }
    if (STYLE_WORDS[rest]) {
      s.setStyle(STYLE_WORDS[rest]);
      log('Sensor ▸ ' + STYLES[s.style].name, 'c-ok');
      return;
    }
    log('Styles: ' + STYLE_KEYS.map((k, i) => (i + 1) + ' ' + TSTYLE[k]).join(' · '), 'c-warn');
    return;
  }
  if (w0 === 'detect') {
    const on = words[1] !== 'off';
    if (s.detect !== on) s.toggleLayer('detect');
    log('DETECTION MESH ' + (on ? 'ON' : 'OFF'), 'c-ok');
    return;
  }
  if (w0 === 'labels' || w0 === 'label') {
    const on = words[1] !== 'off';
    if (s.labels !== on) s.toggleLayer('labels');
    log('LABELS ' + (on ? 'FORCED' : 'AUTO'), 'c-ok');
    return;
  }
  if (w0 === 'spin') {
    const on = words[1] !== 'off';
    if (s.spin !== on) s.toggleLayer('spin');
    log('AUTO-SPIN ' + (on ? 'ON' : 'OFF'), 'c-ok');
    return;
  }
  if (w0 === 'hud') {
    const on = words[1] !== 'off';
    if (s.hud !== on) s.toggleLayer('hud');
    log('HUD ' + (on ? 'ON' : 'OFF'), 'c-ok');
    return;
  }
  if (w0 === 'pit' || q === 'cockpit' || q === 'enter pit' || q === 'pit mode') {
    if (s.track) {
      s.setMode('pit');
      log('PIT MODE ▸ ' + s.track.name.toUpperCase() + ' — modeled geometry, public assay data.', 'c-ok');
      return;
    }
    log('Track a site first — then PIT.', 'c-warn');
    return;
  }
  if (w0 === 'tour') {
    const t = words[1];
    if (t && TOURS[t]) {
      startTour(t, s, log);
      return;
    }
    log('Tours: ' + Object.keys(TOURS).join(' · '), 'c-warn');
    return;
  }
  if (w0 === 'assay') {
    const r = findSites(words.slice(1).join(' '));
    if (!r.length) {
      log('No site matched.', 'c-err');
      return;
    }
    const ss = r[0] as Site;
    log('ASSAY ▸ ' + ss.name.toUpperCase() + ' [' + ss.code + '] — ' + ss.grade + ' · ' + ss.prod + ' · ' + ss.status + '. ' + ss.note, 'c-ok');
    return;
  }
  if (w0 === 'price' || w0 === 'quote') {
    const rest = norm(words.slice(1).join(' '));
    const c = commFromWord(rest);
    const p = PRICES.find((x) => norm(x.k) === rest || norm(x.n).includes(rest) || (c && norm(x.n).includes(norm(COMMS[c].name))));
    if (p) {
      const chg = (p.val - p.prev) / p.prev * 100;
      log('WIRE ▸ ' + p.n + ' ' + fmtN(p.val.toFixed(p.val > 500 ? 0 : 2)) + ' ' + p.u + ' (' + (chg >= 0 ? '+' : '') + chg.toFixed(2) + '%) — SIMULATED.', 'c-ok');
      return;
    }
    log('Metals: ' + PRICES.map((x) => x.k).join(' · '), 'c-warn');
    return;
  }
  if (w0 === 'stats' || q.startsWith('how many')) {
    const m = q.match(/how many\s+([a-z ]+)\s*(mines|sites)?/);
    if (m) {
      const c = commFromWord(m[1]);
      if (c) {
        log(MINES.filter((x) => x.comms.includes(c)).length + ' ' + COMMS[c].name.toUpperCase() + ' sites in dataset — ' + MINES.filter((x) => x.comms.includes(c) && x.status === 'A').length + ' active.', 'c-ok');
        return;
      }
    }
    log('DATASET ▸ ' + MINES.length + ' mines · ' + 11 + ' tailings records · ' + 7 + ' plants · ' + SITES.length + ' total contacts. ' + s.contactCount + ' in view.', 'c-ok');
    return;
  }
  if (q === "whats this" || q === 'what is this') {
    if (!s.track) {
      log('Nothing tracked. Click a contact, or "track <name>".', 'c-warn');
      return;
    }
    const t = s.track;
    log('THIS ▸ ' + t.name + ' [' + t.code + '] — ' + METHOD[kindOf(t)] + ', ' + t.cc + ', operator ' + t.op + '. ' + t.note, 'c-ok');
    return;
  }
  if (w0 === 'contacts' || w0 === 'roster') {
    log('CONTACTS panel up — nearest sites listed. Use the right panel.', 'c-ok');
    return;
  }
  if (w0 === 'zoom') {
    if (words[1] === 'out') {
      s.cam.zoomT = Math.max(0.9, s.cam.zoomT / 1.8);
      log('ZOOM ▸ OUT', 'c-ok');
      return;
    }
    if (words[1] === 'in') {
      s.cam.zoomT = Math.min(12, s.cam.zoomT * 1.8);
      log('ZOOM ▸ IN', 'c-ok');
      return;
    }
    const z = parseFloat(words[1]);
    if (z) {
      s.cam.zoomT = clamp(z, 0.9, 12);
      log('ZOOM ▸ ' + z, 'c-ok');
      return;
    }
  }
  if (w0 === 'next' || w0 === 'n') {
    stepContact(1, s, log);
    return;
  }
  if (w0 === 'prev') {
    stepContact(-1, s, log);
    return;
  }
  if (w0 === 'sources' || w0 === 'about' || w0 === 'power') {
    log('Use the POWER UP button (top-right) to open the source register modal.', 'c-warn');
    return;
  }
  if (w0 === 'share') {
    shareLink(s, log);
    return;
  }
  if (w0 === 'seismic' || w0 === 'blast') {
    s.pushQuake();
    log('Seismic event seeded near a monitored mine (SIM).', 'c-ok');
    return;
  }
  // Bare commodity name?
  const c = commFromWord(q);
  if (c) {
    if (!s.comm[c]) s.toggleComm(c);
    const flySite = SITES.find((x) => !x.tsf && !x.pl && x.comms.includes(c) && x.t1);
    if (flySite) s.trackSite(flySite);
    log(COMMS[c].name.toUpperCase() + ' LAYER ON — ' + MINES.filter((x) => x.comms.includes(c)).length + ' sites lit. Tracking ' + (flySite ? flySite.name : '—') + '.', 'c-ok');
    return;
  }
  // Bare site name?
  const r = findSites(q);
  if (r.length === 1) {
    s.trackSite(r[0]);
    log('TRACKING ▸ ' + r[0].name.toUpperCase() + ' [' + r[0].code + ']', 'c-ok');
    return;
  }
  if (r.length > 1) {
    listMatches(r, log);
    return;
  }
  if (q) log('Unknown command. Try "help".', 'c-err');
}

function helpText(log: (html: string, cls?: string) => void) {
  log('DIRECT — <span class="c-warn">fly &lt;target&gt;</span> · <span class="c-warn">track &lt;target&gt;</span> · <span class="c-warn">zoom out</span> · <span class="c-warn">reset</span> · <span class="c-warn">tour copper|battery|iron|precious|hazards</span> · <span class="c-warn">pit</span>', 'c-txt');
  log('QUERY — <span class="c-warn">assay &lt;site&gt;</span> · <span class="c-warn">price copper</span> · <span class="c-warn">how many lithium mines</span> · <span class="c-warn">what&#39;s this</span> · <span class="c-warn">stats</span>', 'c-txt');
  log('OPERATE — <span class="c-warn">show|hide copper / tailings / all</span> · <span class="c-warn">nvg · crt · flir · noir · spectral</span> · <span class="c-warn">detect on</span> · <span class="c-warn">labels</span> · <span class="c-warn">spin</span> · <span class="c-warn">next</span> · <span class="c-warn">clear</span>', 'c-txt');
}

function listMatches(r: Site[], log: (html: string, cls?: string) => void) {
  log('MULTIPLE CONTACTS:<br>' + r.map((s) => '&nbsp;&nbsp;<span class="c-warn">' + GLY[kindOf(s)] + '</span> ' + s.name + ' [' + s.code + ']').join('<br>'), 'c-txt');
}

function stepContact(d: number, s: MotherlodeState, log: (html: string, cls?: string) => void) {
  const list = s.rosterList;
  if (!list.length) {
    log('Roster empty.', 'c-warn');
    return;
  }
  const idx = (s.rosterIdx + d + list.length) % list.length;
  s.setRoster(list, idx);
  s.trackSite(list[idx]);
  log('CONTACT ' + (idx + 1) + '/' + list.length + ' ▸ ' + s.track?.name.toUpperCase(), 'c-ok');
}

function resetGlobe(s: MotherlodeState) {
  if (s.tour) s.setTour(null);
  flyTo(s.cam, 15, 0, 1, 1600);
  s.toggleLayer('spin'); // ensure spin on
  if (!s.spin) s.toggleLayer('spin');
  s.showToast('RESET ▸ FULL GLOBE');
}

function startTour(name: string, s: MotherlodeState, log: (html: string, cls?: string) => void) {
  if (s.mode === 'pit') s.setMode('globe');
  if (!s.tsf && name === 'hazards') s.toggleLayer('tsf');
  const steps = TOURS[name].map((pair) => ({
    site: SITES.find((x) => x.id === pair[0])!,
    zoom: pair[1],
  })).filter((st) => st.site);
  s.setTour({
    name,
    steps,
    i: 0,
    timer: null,
  });
  s.showToast('TOUR ▸ ' + name.toUpperCase());
  log('TOUR STARTED ▸ ' + name.toUpperCase() + ' — ' + steps.length + ' stops. ESC exits.', 'c-ok');
  // Step immediately
  nextTourStep(s);
}

export function nextTourStep(_s?: MotherlodeState) {
  // Read live state — argument may be stale
  const live = useStore.getState();
  const T = live.tour;
  if (!T) return;
  const st = T.steps[T.i];
  if (!st) {
    live.setTour(null);
    live.showToast('TOUR COMPLETE');
    return;
  }
  live.trackSite(st.site, { fly: false });
  flyTo(live.cam, st.site.lat, st.site.lng, st.zoom, 2600);
  if (T.timer) clearTimeout(T.timer);
  const timerId = setTimeout(() => {
    const cur = useStore.getState();
    if (cur.tour) {
      // Replace with new object so subscribers (TourBar) re-render
      cur.setTour({ ...cur.tour, i: cur.tour.i + 1 });
      nextTourStep();
    }
  }, 4600);
  // Store the timer id on the new tour object so endTour can cancel it
  live.setTour({ ...T, timer: timerId });
}

export function endTour(s: MotherlodeState) {
  if (s.tour?.timer) clearTimeout(s.tour.timer);
  s.setTour(null);
}

function shareLink(s: MotherlodeState, log: (html: string, cls?: string) => void) {
  const p = new URLSearchParams();
  p.set('s', s.style);
  p.set('c', Object.keys(s.comm).filter((k) => s.comm[k as Comm]).join(','));
  if (s.tsf) p.set('h', '1');
  if (s.plant) p.set('p', '1');
  p.set('y', (s.cam.yaw / D2R).toFixed(1));
  p.set('t', (s.cam.tilt / D2R).toFixed(1));
  p.set('z', s.cam.zoom.toFixed(2));
  if (s.track) p.set('tr', s.track.id);
  const url = location.origin + location.pathname + '#' + p.toString();
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).catch(() => {});
  }
  s.showToast('LINK COPIED — CAMERA · STYLE · LAYERS · TARGET');
  log('SHARE LINK serialized to clipboard. A tracked target is a handoff, not a bookmark.', 'c-ok');
}

// Build URL hash state on init
export function applyHash(): boolean {
  if (typeof window === 'undefined' || !location.hash || location.hash.length < 3) return false;
  try {
    const s = useStore.getState();
    const p = new URLSearchParams(location.hash.slice(1));
    const styleKey = p.get('s') as StyleKey | null;
    if (styleKey && STYLES[styleKey]) s.setStyle(styleKey);
    const c = p.get('c');
    if (c !== null) {
      const on = c.split(',');
      (Object.keys(s.comm) as Comm[]).forEach((k) => {
        s.comm[k] = on.includes(k);
      });
    }
    if (p.get('h') === '1' && !s.tsf) s.toggleLayer('tsf');
    if (p.get('h') !== '1' && s.tsf) s.toggleLayer('tsf');
    if (p.get('p') === '1' && !s.plant) s.toggleLayer('plant');
    if (p.get('p') !== '1' && s.plant) s.toggleLayer('plant');
    if (p.get('z')) s.cam.zoom = s.cam.zoomT = clamp(parseFloat(p.get('z')!), 0.9, 12);
    if (p.get('y')) s.cam.yaw = parseFloat(p.get('y')!) * D2R;
    if (p.get('t')) s.cam.tilt = clamp(parseFloat(p.get('t')!) * D2R, -1.25, 1.25);
    if (p.get('tr')) {
      const site = SITES.find((x) => x.id === p.get('tr'));
      if (site) s.trackSite(site, { fly: false });
    }
    return true;
  } catch (err) {
    return false;
  }
}

// Suppress unused-import warnings; these are re-exported for components
void siteOn;
void markerColor;
void normAng;

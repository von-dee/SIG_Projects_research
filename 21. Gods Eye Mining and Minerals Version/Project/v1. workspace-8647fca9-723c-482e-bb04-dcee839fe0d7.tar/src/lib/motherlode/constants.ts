// MOTHERLODE — Static constants (glyphs, methods, hazard colors)

import type { Comm, HazardLevel, Site, SiteType } from './types';

export const D2R = Math.PI / 180;
export const TAU = Math.PI * 2;

export const clamp = (v: number, a: number, b: number) =>
  v < a ? a : v > b ? b : v;
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeIO = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
export const normAng = (a: number) => {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
};
export const fmtN = (n: number | string) =>
  Number(n).toLocaleString('en-US');
export const hash = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
};

export function haversine(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const dLa = (b.lat - a.lat) * D2R;
  const dLo = (b.lng - a.lng) * D2R;
  const x =
    Math.sin(dLa / 2) ** 2 +
    Math.cos(a.lat * D2R) * Math.cos(b.lat * D2R) * Math.sin(dLo / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

export function mix(h1: string, h2: string, t: number) {
  const p = (h: string) => [
    parseInt(h.slice(1, 3), 16),
    parseInt(h.slice(3, 5), 16),
    parseInt(h.slice(5, 7), 16),
  ];
  const a = p(h1);
  const b = p(h2);
  return (
    '#' +
    a
      .map((v, i) =>
        Math.round(lerp(v, b[i], t)).toString(16).padStart(2, '0'),
      )
      .join('')
  );
}

export function hexA(h: string, a: number) {
  const r = parseInt(h.slice(1, 3), 16);
  const g = parseInt(h.slice(3, 5), 16);
  const b = parseInt(h.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${a})`;
}

// Glyph (Unicode) per site kind — kept as Unicode, the canvas font handles them.
export const GLY: Record<string, string> = {
  OP: '▲',
  UG: '●',
  BR: '◆',
  AL: '◆',
  DV: '△',
  CL: '×',
  TSF: '■',
  PL: '◎',
};

export const METHOD: Record<string, string> = {
  OP: 'Open pit',
  UG: 'Underground',
  BR: 'Brine / evaporation',
  AL: 'Alluvial',
  TSF: 'Tailings facility',
  PL: 'Processing plant',
};

export const HAZCOL: Record<HazardLevel, string> = {
  FAILED: '#ff5f56',
  EXTREME: '#ff8a3c',
  HIGH: '#ffb454',
  LEAK: '#ffd24a',
  DISCHARGE: '#5bd6dd',
};

export const kindOf = (s: Site): string =>
  s.tsf ? 'TSF' : s.pl ? 'PL' : s.status === 'C' ? 'CL' : s.status === 'D' ? 'DV' : s.type;

export const POND_COLS = ['#a8e0ef', '#8ecde0', '#f2d9a0', '#e8b075', '#d97f5a'];

export const COMM_ORDER: Comm[] = [
  'CU', 'FE', 'ZN', 'C', 'BX',
  'AU', 'AG', 'PG',
  'LI', 'NI', 'CO', 'REE', 'U',
  'MO', 'SN', 'K', 'P', 'DIA',
];

export const CGROUPS: [string, Comm[]][] = [
  ['BULK & BASE', ['CU', 'FE', 'ZN', 'C', 'BX']],
  ['PRECIOUS', ['AU', 'AG', 'PG']],
  ['ENERGY TRANSITION', ['LI', 'NI', 'CO', 'REE', 'U']],
  ['SPECIALTY & FERTILIZER', ['MO', 'SN', 'K', 'P', 'DIA']],
];

export const TOURS: Record<string, [string, number][]> = {
  copper: [
    ['escondida', 3.6], ['chuqui', 3.6], ['collahuasi', 3.4],
    ['antamina', 3.2], ['grasberg', 3.6], ['morenci', 3.2],
    ['bingham', 3.8], ['oyu', 3.2], ['kakula', 3.2],
  ],
  battery: [
    ['atacama', 3.8], ['hombre', 3.6], ['greenbushes', 3.6],
    ['pilgangoora', 3.2], ['thacker', 3.4], ['mutanda', 3.2], ['norilsk', 3.0],
  ],
  iron: [
    ['carajas', 3.4], ['whaleback', 3.6], ['tomprice', 3.2],
    ['kiruna', 3.6], ['simandou', 3.4],
  ],
  precious: [
    ['muruntau', 3.6], ['nevada', 3.0], ['superpit', 3.6],
    ['mponeng', 3.2], ['potosi', 3.6],
  ],
  hazards: [
    ['feijao', 4.0], ['fundao', 4.0], ['polley', 3.8], ['frailes', 4.2],
    ['cadia-ntsf', 3.2], ['el-mauro', 3.2], ['ok-tedi', 3.6],
  ],
};

export const MISSIONS: { t: string; d: string }[] = [
  {
    t: 'LIGHT UP THE BELT',
    d: "Every major copper producer on Earth. Fly the Antofagasta belt and track the biggest hole in it.",
  },
  {
    t: 'BATTERY CHAIN',
    d: 'Lithium, nickel, cobalt, rare earths — the electrification supply chain from Andean brine to Arctic block cave.',
  },
  {
    t: 'HAZARD WATCH',
    d: 'Tailings facilities with consequence ratings, failure case files, incident wire live. Watch the dams.',
  },
  {
    t: 'IRON GIANTS',
    d: "Carajás to the Pilbara to Kiruna — the mega pits that feed half the world's steel.",
  },
  {
    t: 'EXPLORE MANUALLY',
    d: 'Everything on, no autopilot. Click anything. Type anything. Break it.',
  },
];

export const BOOT_LINES: [string, string][] = [
  ['MOTHERLODE SURVEY TERMINAL v0.2.0 — "KEYLESS BOOT" REACT EDITION', ''],
  ['> mounting local data stores …', 'dim'],
  ['  USGS/MRDS register … 91 SITES OK', 'dim'],
  ['  GLOBAL TAILINGS PORTAL … 11 RECORDS OK', 'dim'],
  ['  PROCESSING REGISTER … 7 NODES OK', 'dim'],
  ['  COMMODITY WIRE … SIMULATED FEED ARMED', 'dim'],
  ['> renderer: CANVAS / ORTHOGRAPHIC … OK', 'dim'],
  ['> sensor stack: TACTICAL CRT NVG IRONBOW WHITE-HOT NOIR SPECTRAL … 7/7', 'dim'],
  ['> console agent: LOCAL PARSER — NO KEY REQUIRED … OK', 'dim'],
  ['> framework: REACT 19 + NEXT.JS 16 + TYPESCRIPT + ZUSTAND … OK', 'dim'],
  ['> NOTICE: positions approximate · prices simulated · not for navigation', 'dim'],
  ['BOOT COMPLETE — 0 keys · 0 accounts · 100% local.', 'ok'],
];

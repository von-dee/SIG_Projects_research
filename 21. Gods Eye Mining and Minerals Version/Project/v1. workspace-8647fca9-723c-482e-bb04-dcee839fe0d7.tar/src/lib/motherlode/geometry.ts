// MOTHERLODE — Camera / projection helpers for the orthographic globe view

import { D2R, TAU, clamp, lerp, normAng, easeIO } from './constants';

export interface Camera {
  yaw: number;
  tilt: number;
  zoom: number;
  zoomT: number;
  vyaw: number;
  vtilt: number;
  anim: {
    from: { yaw: number; tilt: number; zoom: number };
    to: { yaw: number; tilt: number; zoom: number };
    t0: number;
    dur: number;
  } | null;
}

export function makeCamera(): Camera {
  return {
    yaw: 0.6,
    tilt: 0.32,
    zoom: 1,
    zoomT: 1,
    vyaw: 0,
    vtilt: 0,
    anim: null,
  };
}

export function globeR(W: number, H: number, cam: Camera) {
  return Math.min(W, H) * 0.42 * cam.zoom;
}

export function project(
  lat: number,
  lng: number,
  cam: Camera,
  W: number,
  H: number,
): [number, number, number] | null {
  const la = lat * D2R;
  const lo = lng * D2R + cam.yaw;
  const x = Math.cos(la) * Math.sin(lo);
  const z = Math.cos(la) * Math.cos(lo);
  const y = Math.sin(la);
  const ct = Math.cos(cam.tilt);
  const st = Math.sin(cam.tilt);
  const y2 = y * ct - z * st;
  const z2 = y * st + z * ct;
  if (z2 <= 0.015) return null;
  const R = globeR(W, H, cam);
  return [W / 2 + x * R, H / 2 - y2 * R, z2];
}

export function rawDir(
  lat: number,
  lng: number,
  cam: Camera,
): [number, number] {
  const la = lat * D2R;
  const lo = lng * D2R + cam.yaw;
  const x = Math.cos(la) * Math.sin(lo);
  const z = Math.cos(la) * Math.cos(lo);
  const y = Math.sin(la);
  const ct = Math.cos(cam.tilt);
  const st = Math.sin(cam.tilt);
  return [x, y * ct - z * st];
}

export function flyTo(
  cam: Camera,
  lat: number,
  lng: number,
  zoom?: number,
  dur?: number,
) {
  dur = dur ?? 2400;
  const to = {
    yaw: cam.yaw + normAng(-lng * D2R - cam.yaw),
    tilt: clamp(lat * D2R, -1.22, 1.22),
    zoom: zoom ?? cam.zoomT,
  };
  cam.anim = {
    from: { yaw: cam.yaw, tilt: cam.tilt, zoom: cam.zoom },
    to,
    t0: performance.now(),
    dur,
  };
  cam.zoomT = to.zoom;
}

export function stepCam(cam: Camera, dt: number, opts: {
  spin: boolean;
  mode: 'globe' | 'pit';
  tour: unknown | null;
  lastPointer: number;
}) {
  if (cam.anim) {
    const a = cam.anim;
    const p = clamp((performance.now() - a.t0) / a.dur, 0, 1);
    const e = easeIO(p);
    cam.yaw = lerp(a.from.yaw, a.to.yaw, e);
    cam.tilt = lerp(a.from.tilt, a.to.tilt, e);
    cam.zoom = lerp(a.from.zoom, a.to.zoom, e);
    if (p >= 1) cam.anim = null;
  } else {
    cam.yaw += cam.vyaw;
    cam.tilt += cam.vtilt;
    cam.vyaw *= 0.93;
    cam.vtilt *= 0.93;
    cam.zoom += (cam.zoomT - cam.zoom) * 0.14;
    if (
      opts.spin &&
      opts.mode === 'globe' &&
      performance.now() - opts.lastPointer > 4000 &&
      !opts.tour
    ) {
      cam.yaw += 0.00028 * dt;
    }
  }
}

export function centerLatLon(cam: Camera): [number, number] {
  return [cam.tilt / D2R, normAng(-cam.yaw) / D2R];
}

export const _TAU = TAU; // re-exported for canvas consumers

// MOTHERLODE — Build the master site registry with assigned IDs/codes

import { MINES, TSFS, PLANTS } from './data';
import type { Site } from './types';

export const SITES: Site[] = [...MINES, ...TSFS, ...PLANTS];

// Assign per-commodity sequential codes to mines; TSF-NN and PL-NN to others
(function buildCodes() {
  const ci: Record<string, number> = {};
  MINES.forEach((m) => {
    const c = m.comms[0];
    ci[c] = (ci[c] ?? 0) + 1;
    m.code = `${c}-${String(ci[c]).padStart(3, '0')}`;
  });
  TSFS.forEach((f, i) => {
    f.code = `TSF-${String(i + 1).padStart(2, '0')}`;
  });
  PLANTS.forEach((p, i) => {
    p.code = `PL-${String(i + 1).padStart(2, '0')}`;
  });
})();

export function findSiteById(id: string): Site | undefined {
  return SITES.find((s) => s.id === id);
}

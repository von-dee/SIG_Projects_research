// MOTHERLODE — Zustand store for global UI/camera state

'use client';

import { create } from 'zustand';
import type {
  Camera, Comm, Quake, Blip, WireItem, Site, StyleKey, TourState,
} from './types';
import { makeCamera } from './geometry';
import { COMMS, MINES, TSFS, PLANTS, PRICES } from './data';
import { SITES } from './sites';
import { clamp, D2R, fmtN, hash, normAng } from './constants';

export type ConsoleLine = {
  id: number;
  html: string;
  cls: string;
};

export type BootStage = 'typing' | 'missions' | 'done';

export interface MotherlodeState {
  // Camera (mutable, not reactive — referenced by canvas)
  cam: Camera;
  W: number;
  H: number;
  dpr: number;
  lastPointer: number;

  // Layer toggles
  comm: Record<Comm, boolean>;
  tsf: boolean;
  plant: boolean;

  // Display toggles
  style: StyleKey;
  detect: boolean;
  labels: boolean;
  grid: boolean;
  spin: boolean;
  hud: boolean;
  incidents: boolean;
  seis: boolean;

  // Tracking + mode
  track: Site | null;
  mode: 'globe' | 'pit';
  tour: TourState | null;
  contactCount: number;

  // Roster
  rosterList: Site[];
  rosterIdx: number;

  // Live telemetry (simulated)
  ore: number;
  energy: number;
  fleet: number;

  // Transient world state (kept in store but not used in render deps)
  quakes: Quake[];
  blips: Blip[];
  wire: WireItem[];
  prices: typeof PRICES;

  // Console
  consoleLines: ConsoleLine[];
  consoleInput: string;

  // Boot / splash
  bootStage: BootStage;
  bootChars: string;

  // Toast
  toast: string | null;

  // fps
  fps: number;

  // ---- actions ----
  setViewport: (W: number, H: number, dpr: number) => void;
  setStyle: (k: StyleKey) => void;
  toggleLayer: (key: 'tsf' | 'plant' | 'detect' | 'labels' | 'grid' | 'spin' | 'hud' | 'incidents' | 'seis') => void;
  toggleComm: (c: Comm) => void;
  setCommAll: (on: boolean) => void;

  trackSite: (s: Site | null, opts?: { fly?: boolean }) => void;
  setMode: (m: 'globe' | 'pit') => void;
  setTour: (t: TourState | null) => void;

  pushQuake: () => void;
  pushAlert: (sev: WireItem['sev'], text: string, ref?: Site) => void;
  stepPrices: () => void;
  tickTelemetry: () => void;
  pushConsole: (html: string, cls?: string) => void;
  clearConsole: () => void;
  setConsoleInput: (s: string) => void;

  setBootStage: (s: BootStage) => void;
  setBootChars: (s: string) => void;

  showToast: (msg: string) => void;
  setFps: (n: number) => void;
  setContactCount: (n: number) => void;
  setRoster: (list: Site[], idx: number) => void;
  setCam: (c: Partial<Camera>) => void;
  setLastPointer: (t: number) => void;
}

const initialComm: Record<Comm, boolean> = {
  CU: true, FE: true, ZN: true, C: true, BX: true,
  AU: true, AG: true, PG: true,
  LI: true, NI: true, CO: true, REE: true, U: true,
  MO: true, SN: true, K: true, P: true, DIA: true,
};

let toastTimer: ReturnType<typeof setTimeout> | null = null;
let consoleId = 0;

export const useStore = create<MotherlodeState>((set, get) => ({
  cam: makeCamera(),
  W: typeof window !== 'undefined' ? window.innerWidth : 1280,
  H: typeof window !== 'undefined' ? window.innerHeight : 720,
  dpr: typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1,
  lastPointer: 0,

  comm: { ...initialComm },
  tsf: true,
  plant: false,

  style: 'normal',
  detect: false,
  labels: false,
  grid: true,
  spin: true,
  hud: true,
  incidents: true,
  seis: true,

  track: null,
  mode: 'globe',
  tour: null,
  contactCount: 0,

  rosterList: [],
  rosterIdx: 0,

  ore: 0,
  energy: 0,
  fleet: 0,

  quakes: [],
  blips: [],
  wire: [],
  prices: PRICES.map((p) => ({ ...p })),

  consoleLines: [],
  consoleInput: '',

  bootStage: 'typing',
  bootChars: '',

  toast: null,

  fps: 60,

  setViewport: (W, H, dpr) => set({ W, H, dpr }),
  setStyle: (k) => set({ style: k }),
  toggleLayer: (key) =>
    set((st) => ({ [key]: !st[key] }) as Partial<MotherlodeState>),
  toggleComm: (c) =>
    set((st) => ({ comm: { ...st.comm, [c]: !st.comm[c] } })),

  setCommAll: (on) =>
    set((st) => {
      const next = { ...st.comm };
      (Object.keys(next) as Comm[]).forEach((k) => (next[k] = on));
      return { comm: next };
    }),

  trackSite: (s, opts = {}) => {
    if (!s) {
      set({ track: null });
      return;
    }
    const cam = get().cam;
    set({
      track: s,
      ore: Math.round(20000 + Math.random() * 180000),
      energy: Math.round(80 + Math.random() * 300),
      fleet: 4 + Math.floor(Math.random() * 18),
    });
    if (opts.fly !== false) {
      const target = Math.max(cam.zoomT, 3.4);
      flyToStore(cam, s.lat, s.lng, target);
    }
    set({ spin: false });
  },

  setMode: (m) => set({ mode: m }),
  setTour: (t) => set({ tour: t }),

  pushQuake: () => {
    const pool = MINES.filter(
      (m) =>
        m.status === 'A' &&
        ['mponeng','teniente','norilsk','sudbury','chuqui','kakula','oyu'].includes(m.id),
    );
    const m = pool[Math.floor(Math.random() * pool.length)] ?? MINES[0];
    const q: Quake = {
      lat: m.lat + (Math.random() - 0.5) * 1.2,
      lng: m.lng + (Math.random() - 0.5) * 1.2,
      t0: performance.now(),
      mag: (1.5 + Math.random() * 1.9).toFixed(1),
      ref: m,
    };
    const arr = [...get().quakes, q];
    if (arr.length > 7) arr.shift();
    set({ quakes: arr });
  },

  pushAlert: (sev, text, ref) => {
    const d = new Date();
    const time =
      String(d.getUTCHours()).padStart(2, '0') +
      ':' +
      String(d.getUTCMinutes()).padStart(2, '0');
    const item: WireItem = { sev, text, ref, time };
    const wire = [item, ...get().wire].slice(0, 40);
    set({ wire });
    if (ref && get().incidents) {
      const blip: Blip = { s: ref, t0: performance.now(), sev };
      const blips = [...get().blips, blip];
      if (blips.length > 10) blips.shift();
      set({ blips });
    }
  },

  stepPrices: () =>
    set((st) => ({
      prices: st.prices.map((p) => {
        const prev = p.val;
        const val = p.val * (1 + (Math.random() - 0.5) * 0.007);
        return { ...p, prev, val };
      }),
    })),

  tickTelemetry: () => {
    const s = get();
    if (!s.track) return;
    const ore = s.ore + Math.round(60 + Math.random() * 240);
    const energy = s.energy + Math.random() * 0.8;
    let fleet = s.fleet;
    if (Math.random() < 0.06)
      fleet = clamp(fleet + (Math.random() < 0.5 ? -1 : 1), 2, 24);
    set({ ore, energy, fleet });
  },

  pushConsole: (html, cls = 'c-txt') =>
    set((st) => {
      const next = [
        ...st.consoleLines,
        { id: ++consoleId, html, cls },
      ];
      while (next.length > 60) next.shift();
      return { consoleLines: next };
    }),

  clearConsole: () => set({ consoleLines: [] }),
  setConsoleInput: (s) => set({ consoleInput: s }),

  setBootStage: (s) => set({ bootStage: s }),
  setBootChars: (s) => set({ bootChars: s }),

  showToast: (msg) => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: msg });
    toastTimer = setTimeout(() => set({ toast: null }), 2400);
  },

  setFps: (n) => set({ fps: n }),
  setContactCount: (n) => set({ contactCount: n }),
  setRoster: (list, idx) => set({ rosterList: list, rosterIdx: idx }),
  setCam: (c) =>
    set((st) => ({ cam: { ...st.cam, ...c } as Camera })),
  setLastPointer: (t) => set({ lastPointer: t }),
}));

// --- helpers (kept outside store state) ---

function flyToStore(cam: Camera, lat: number, lng: number, zoom: number) {
  const dur = 2400;
  const to = {
    yaw: cam.yaw + normAng(-lng * D2R - cam.yaw),
    tilt: clamp(lat * D2R, -1.22, 1.22),
    zoom,
  };
  cam.anim = {
    from: { yaw: cam.yaw, tilt: cam.tilt, zoom: cam.zoom },
    to,
    t0: performance.now(),
    dur,
  };
  cam.zoomT = to.zoom;
}

// Site-on-screen helper (used by Globe + Roster)
export function siteOn(s: Site, st: Pick<MotherlodeState, 'comm' | 'tsf' | 'plant'>): boolean {
  if (s.tsf) return st.tsf;
  if (s.pl) return st.plant;
  return s.comms.some((c) => st.comm[c]);
}

// Commodity color lookup helper for marker rendering
export function markerColor(s: Site, st: MotherlodeState, palette: {
  mode: string;
  mono?: string;
  accent: string;
  cy?: string;
}): string {
  const P = palette;
  if (P.mode === 'mono') return P.mono || '#fff';
  if (P.mode === 'heat') return s.t1 ? '#ffd28a' : '#b8491f';
  if (P.mode === 'heat2') return s.t1 ? '#ffffff' : '#8a8a8a';
  if (s.tsf) return s.haz === 'FAILED' ? '#ff5f56'
    : s.haz === 'EXTREME' ? '#ff8a3c'
    : s.haz === 'HIGH' ? '#ffb454'
    : s.haz === 'LEAK' ? '#ffd24a'
    : '#5bd6dd';
  if (s.pl) return P.cy || '#5bd6dd';
  return COMMS[s.comms[0]].col;
}

// Format a console-ready price/quote string
export function fmtPrice(p: { k: string; n: string; u: string; val: number; prev: number }): string {
  const chg = (p.val - p.prev) / p.prev * 100;
  return `${p.n} ${fmtN(p.val.toFixed(p.val > 500 ? 0 : 2))} ${p.u} (${chg >= 0 ? '+' : ''}${chg.toFixed(2)}%)`;
}

export { SITES, hash };

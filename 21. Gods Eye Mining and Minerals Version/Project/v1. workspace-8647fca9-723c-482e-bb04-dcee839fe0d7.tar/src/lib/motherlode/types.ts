// MOTHERLODE — Type definitions for the Mineral Survey Console

export type Comm =
  | 'CU' | 'FE' | 'ZN' | 'C' | 'BX'
  | 'AU' | 'AG' | 'PG'
  | 'LI' | 'NI' | 'CO' | 'REE' | 'U'
  | 'MO' | 'SN' | 'K' | 'P' | 'DIA';

export type SiteType = 'OP' | 'UG' | 'BR' | 'AL';
export type SiteStatus = 'A' | 'D' | 'C';
export type HazardLevel = 'FAILED' | 'EXTREME' | 'HIGH' | 'LEAK' | 'DISCHARGE';

export interface Commodity {
  key: Comm;
  name: string;
  col: string;
}

export interface Mine {
  id: string;
  name: string;
  cc: string;
  op: string;
  comms: Comm[];
  type: SiteType;
  lat: number;
  lng: number;
  prod: string;
  grade: string;
  note: string;
  t1: boolean; // top-tier — always visible
  status: SiteStatus;
  tsf: false;
  pl: false;
  // assigned at runtime:
  code?: string;
  vis?: boolean;
  sx?: number;
  sy?: number;
}

export interface TailingsFacility {
  id: string;
  name: string;
  cc: string;
  op: string;
  lat: number;
  lng: number;
  haz: HazardLevel;
  vol: string;
  status: 'CLOSED' | 'ACTIVE' | 'ONGOING';
  note: string;
  t1: boolean;
  tsf: true;
  pl: false;
  comms: never[];
  type: SiteType;
  prod: string;
  grade: string;
  // assigned at runtime:
  code?: string;
  vis?: boolean;
  sx?: number;
  sy?: number;
}

export interface ProcessingPlant {
  id: string;
  name: string;
  cc: string;
  op: string;
  out: string;
  lat: number;
  lng: number;
  pl: true;
  tsf: false;
  comms: never[];
  type: SiteType;
  prod: string;
  grade: string;
  status: SiteStatus;
  note: string;
  // assigned at runtime:
  code?: string;
  vis?: boolean;
  sx?: number;
  sy?: number;
}

export type Site = Mine | TailingsFacility | ProcessingPlant;

export interface Region {
  id: string;
  lat: number;
  lng: number;
  zoom: number;
  label: string;
}

export interface Price {
  k: string;
  n: string;
  u: string;
  val: number;
  prev: number;
}

export type StyleKey =
  | 'normal' | 'crt' | 'nvg' | 'ironbow'
  | 'whitehot' | 'noir' | 'spectral';

export type StyleMode = 'color' | 'mono' | 'heat' | 'heat2';

export interface StyleDef {
  name: string;
  bg: string;
  star: string;
  ocean: string;
  land: string; // 'dyn' for spectral dynamic colors
  coast: string;
  grid: string;
  text: string;
  accent: string;
  glow: string;
  mode: StyleMode;
  mono?: string;
}

export interface WireItem {
  sev: 'info' | 'warn' | 'alert';
  text: string;
  ref?: Site;
  time: string;
}

export interface Quake {
  lat: number;
  lng: number;
  t0: number;
  mag: string;
  ref: Mine;
}

export interface Blip {
  s?: Site;
  t0: number;
  sev: 'info' | 'warn' | 'alert';
}

export interface CameraState {
  yaw: number;
  tilt: number;
  zoom: number;
  zoomT: number;
  vyaw: number;
  vtilt: number;
  anim: {
    from: { yaw: number; tilt: number; zoom: number };
    to: { yaw: number; tilt: number; zoom: number };
    t0: number;
    dur: number;
  } | null;
}

export interface TourStep {
  site: Site;
  zoom: number;
}

export interface TourState {
  name: string;
  steps: TourStep[];
  i: number;
  timer: ReturnType<typeof setTimeout> | null;
}
